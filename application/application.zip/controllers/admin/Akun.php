<?php
defined('BASEPATH') OR exit('No direct script access allowed');

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class Akun extends CI_Controller {

	private $table1 = 'akun';

	public function __construct()
	{
		parent::__construct();
        Cek_login::ceklogin();
		$this->load->model('Createtable');
		$this->load->model('Datatable_gugus');
	}

	public function index()
	{
        $this->Createtable->location('admin/akun/table_show');
        $this->Createtable->table_name('tableku');
        $this->Createtable->create_row(["No","Kunci","Kode Akun","Nama Akun","Kategori Akun","Pajak","Saldo","Deskripsi", "Tindakan"]);
        $this->Createtable->order_set('0, 8');
				$show = $this->Createtable->create();

				$data['datatable'] = $show;
        $this->load->view('templateadmin/head');
        $this->load->view('admin/akun/view', $data);
        $this->load->view('templateadmin/footer');
	}


	public function cashbank()
	{
        $this->Createtable->location('admin/akun/table_show_cash_bank');
        $this->Createtable->table_name('tableku');
        $this->Createtable->create_row(["No","Kode Akun","Nama Akun","Saldo Bank","Saldo Jurnal", "Tindakan"]);
        $this->Createtable->order_set('0, 5');
				$show = $this->Createtable->create();

				$data['datatable'] = $show;
        $this->load->view('templateadmin/head');
        $this->load->view('admin/akun/view2', $data);
        $this->load->view('templateadmin/footer');
	}

	public function table_show($action = 'show', $keyword = '')
	{
		if ($action == "show") {

            if (isset($_POST['order'])): $setorder = $_POST['order']; else: $setorder = ''; endif;

            $this->Datatable_gugus->datatable(
                [
                    "table" => $this->table1,
                    "select" => [
											"*"
										],
                    'where' => [
                        ['delete_set', '=', '0']
                    ],
                    'limit' => [
                        'start' => post('start'),
                        'end' => post('length')
                    ],
                    'search' => [
                        'value' => $this->Datatable_gugus->search(),
                        'row' => ["kunci","kode_akun","nama_akun","kategori_akun_id","pajak","saldo","deskripsi","created_at","updated_at"]
                    ],
                    'table-draw' => post('draw'),
                    'table-show' => [
                        'key' => 'id',
                        'data' => ["kunci","kode_akun","nama_akun","kategori_akun_id","pajak","saldo","deskripsi"]
                    ],
                    "action" => "standart",
                    'order' => [
                        'order-default' => ['id', 'ASC'],
                        'order-data' => $setorder,
                        'order-option' => [ "1"=>"kunci", "2"=>"kode_akun", "3"=>"nama_akun", "4"=>"kategori_akun_id", "5"=>"pajak", "6"=>"saldo", "7"=>"deskripsi", "8"=>"created_at", "9"=>"updated_at", "10"=>"delete_set"],
                    ],
                     'custome' => [
                    "saldo" => [
                        "key" => ['saldo'],
                        "content" => "
                            <span style=\"float: right;\" class=\"saldo\">{{saldo}}</span>
                        ",
                    ],
                    "kategori_akun_id" => [
                            "replacerow" => [
                                "table" => "kategoriakun",
                                "condition" => ['id'],
                                "value" => ['kategori_akun_id'],
                                "get" => "kategori",
                            ],
                        ],
                    ],
                ]
            );
            $this->Datatable_gugus->table_show();
        }elseif ($action == "update") {
            $data_row = $this->db->query("SELECT * FROM ".$this->table1." WHERE id = '".$keyword."'")->row();
            $data['form_data'] = $data_row;
            $this->load->view('templateadmin/head');
            $this->load->view('admin/akun/edit', $data);
            $this->load->view('templateadmin/footer');
        }elseif ($action == "delete") {
            $hapus_data = $this->db->query("UPDATE ".$this->table1." SET delete_set = '1' WHERE id = '".post("id")."'");
        }
  }

	public function table_show_cash_bank($action = 'show', $keyword = '')
	{
		if ($action == "show") {

            if (isset($_POST['order'])): $setorder = $_POST['order']; else: $setorder = ''; endif;

            $this->Datatable_gugus->datatable(
                [
                    "table" => $this->table1,
                    "select" => [
											"*"
										],
                    'where' => [
                        ['delete_set', '=', '0'],
                        ['kategori_akun_id', '=', cek(Perusahaans::get(),'transaksi')->kasbank->akun->kategori_akun_id],
                    ],
                    'limit' => [
                        'start' => post('start'),
                        'end' => post('length')
                    ],
                    'search' => [
                        'value' => $this->Datatable_gugus->search(),
                        'row' => ["kunci","kode_akun","nama_akun","kategori_akun_id","pajak","saldo","deskripsi","created_at","updated_at"]
                    ],
                    'table-draw' => post('draw'),
                    'table-show' => [
                        'key' => 'id',
                        'data' => ["kode_akun","nama_akun","kategori_akun_id","saldo","id"]
                    ],
                    "action" => "standart",
                    'order' => [
                        'order-default' => ['id', 'ASC'],
                        'order-data' => $setorder,
                        'order-option' => [ "1"=>"kunci", "2"=>"kode_akun", "3"=>"nama_akun", "4"=>"kategori_akun_id", "5"=>"pajak", "6"=>"saldo", "7"=>"deskripsi", "8"=>"created_at", "9"=>"updated_at", "10"=>"delete_set"],
                    ],
                     'custome' => [
	                    "kategori_akun_id" => [
	                        "key" => ['id'],
	                        "content" => "
	                            <span style=\"float: right;\" class=\"saldo1\"></span>
	                        ",
	                    ],
	                    "saldo" => [
	                        "key" => ['id'],
	                        "content" => "
	                            <span style=\"float: right;\" class=\"saldo2\"></span>
	                        ",
	                    ],
	                    "id" => [
	                        "key" => ['id'],
	                        "content" => "
																<center>
																 <div class=\"dropdown\">
																	 <button class=\"btn btn-default dropdown-toggle\" type=\"button\" id=\"dropdownMenuButton{{id}}\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
																		 Import Bank Statement
																	 </button>
																	 <div class=\"dropdown-menu\" aria-labelledby=\"dropdownMenuButton{{id}}\">
																		 <a data-id='{{id}}' class=\"dropdown-item\" href=\"#\"><i class='fas fa-plus'></i> Transfer Uang</a>
																		 <a data-id='{{id}}' class=\"dropdown-item\" href=\"#\"><i class='fas fa-plus'></i> Terima Uang</a>
																	 </div>
																 </div>
															 </center>
	                        ",
	                    ],
                  	],
                ]
            );
            $this->Datatable_gugus->table_show();
        }elseif ($action == "update") {
            $data_row = $this->db->query("SELECT * FROM ".$this->table1." WHERE id = '".$keyword."'")->row();
            $data['form_data'] = $data_row;
            $this->load->view('templateadmin/head');
            $this->load->view('admin/akun/edit', $data);
            $this->load->view('templateadmin/footer');
        }elseif ($action == "delete") {
            $hapus_data = $this->db->query("UPDATE ".$this->table1." SET delete_set = '1' WHERE id = '".post("id")."'");
        }
  }

    public function tambah_data()
    {
        $this->load->view('templateadmin/head');
        $this->load->view('admin/akun/tambah');
        $this->load->view('templateadmin/footer');
    }


    public function simpan(){
        $kunci = post("kunci");
		$kode_akun = post("kode_akun");
		$nama_akun = post("nama_akun");
		$kategori_akun_id = post("kategori_akun_id");
		$pajak = post("pajak");
		$saldo = post("saldo");
		$deskripsi = post("deskripsi");



        $simpan = $this->db->query("
            INSERT INTO akun
            (kunci,kode_akun,nama_akun,kategori_akun_id,pajak,saldo,deskripsi) VALUES ('$kunci','$kode_akun','$nama_akun','$kategori_akun_id','$pajak','$saldo',\"$deskripsi\")
        ");


        if($simpan){
            redirect('admin/akun');
        }
    }

    public function update(){
          $key = post('id'); $kunci = post("kunci");
$kode_akun = post("kode_akun");
$nama_akun = post("nama_akun");
$kategori_akun_id = post("kategori_akun_id");
$pajak = post("pajak");
$saldo = post("saldo");
$deskripsi = post("deskripsi");

        $simpan = $this->db->query("
            UPDATE akun SET  kunci = '$kunci', kode_akun = '$kode_akun', nama_akun = '$nama_akun', kategori_akun_id = '$kategori_akun_id', pajak = '$pajak', saldo = '$saldo', deskripsi = \"$deskripsi\" WHERE id = '$key'
            ");


        if($simpan){
            redirect('admin/akun');
        }
    }



    public function exls(array $data = [], array $headers = [], $fileName = 'data-akun.xlsx')
    {
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        $headers = ["No","Kunci","Kode Akun","Nama Akun","Kategori Akun","Pajak","Saldo","Deskripsi", "action"];

        $calldata = ["kunci","kode_akun","nama_akun","kategori_akun_id","pajak","saldo","deskripsi"];

        for ($i = 0, $l = sizeof($headers); $i < $l; $i++) {
            $sheet->setCellValueByColumnAndRow($i + 1, 1, $headers[$i]);
        }

        $qr = $this->db->query("SELECT * FROM $this->table1")->result();

        foreach($qr as $i => $vv){
            $j = 1;
            $sheet->setCellValueByColumnAndRow(0 + 1, ($i + 1 + 1), $i + 1);
            foreach ($calldata as $k => $v) { // column $j
                $sheet->setCellValueByColumnAndRow($j + 1, ($i + 1 + 1), $vv->$v);
                $j++;
            }
        }

        $writer = new Xlsx($spreadsheet);
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="'. urlencode($fileName).'"');
        $writer->save('php://output');

    }


}
