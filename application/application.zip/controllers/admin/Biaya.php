<?php
defined('BASEPATH') OR exit('No direct script access allowed');

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class Biaya extends CI_Controller {

	private $table1 = 'biaya';

	public function __construct()
	{
		parent::__construct();
        Cek_login::ceklogin();
		$this->load->model('Tabledx');
		$this->load->model('Createtable');
		$this->load->model('Datatable_gugus');
	}

	public function index()
	{
				$data['total'] = $this->biayatotal();
        $this->Createtable->location('admin/biaya/table_show');
        $this->Createtable->table_name('tableku');
        $this->Createtable->create_row(["No","No Biaya","Tanggal Transaksi","Penerima","Tag", "Total Biaya", "action"]);
        $this->Createtable->order_set('0, 6');
				$show = $this->Createtable->create();
				$data['datatable'] = $show;
        $this->load->view('templateadmin/head');
        $this->load->view('admin/biaya/view', $data);
        $this->load->view('templateadmin/footer');
	}


	public function biayatotal()
	{
		$tr = new Tabledx;
		$tr->table($this->table1);
		$tr->select(" SUM(total) as total ");
		$tr->debug();
		return  'Rp. '.rupiah($tr->row()->total);
	}


	public function table_show($action = 'show', $keyword = '')
	{
		if ($action == "show") {

            if (isset($_POST['order'])): $setorder = $_POST['order']; else: $setorder = ''; endif;

            $this->Datatable_gugus->datatable(
                [
                    "table" => $this->table1,
                    "select" => [
											"*"
										],
                    'where' => [
                        ['delete_set', '=', '0']
                    ],
                    'limit' => [
                        'start' => post('start'),
                        'end' => post('length')
                    ],
                    'search' => [
                        'value' => $this->Datatable_gugus->search(),
                        'row' => ["no_biaya","tanggal_transaksi","penerima","tag","total"]
                    ],
                    'table-draw' => post('draw'),
                    'table-show' => [
                        'key' => 'id',
                        'data' => ["no_biaya","tanggal_transaksi","penerima","tag","total"]
                    ],
                    "action" => "standart",
                    'order' => [
                        'order-default' => ['id', 'ASC'],
                        'order-data' => $setorder,
                        'order-option' => [ "1"=>"no_biaya", "2"=>"tanggal_transaksi", "3"=>"Penerima", "4"=>"tag", "5"=>"total"]
                    ],
										"custome" => [
											"total" => [
													"key" => ['total'],
													"content" => "
															<span style=\"float: right;\" class=\"total\">{{total}}</span>
													",
											],
										]
                ]
            );
            $this->Datatable_gugus->table_show();
        }elseif ($action == "update") {
            $data_row = $this->db->query("SELECT * FROM ".$this->table1." WHERE id = '".$keyword."'")->row();
            $data['form_data'] = $data_row;
            $this->load->view('templateadmin/head');
            $this->load->view('admin/biaya/edit', $data);
            $this->load->view('templateadmin/footer');
        }elseif ($action == "delete") {
            $hapus_data = $this->db->query("UPDATE ".$this->table1." SET delete_set = '1' WHERE id = '".post("id")."'");
        }
    }

    public function tambah_data()
    {

			$tr = new Tabledx;
			$tr->table($this->table1);
			$tr->condition([
				"no_biaya" => [
					'opsi' => "LIKE",
					'val' => 'BO'.date('ym').'%',
				]
			]);
			$x = $tr->num_rows() + 1;
			$code = "BO".date('ym');
			$code2 = str_pad($x, 5, '0', STR_PAD_LEFT);
			$data['code'] = $code.'-'.$code2;

        $this->load->view('templateadmin/head');
        $this->load->view('admin/biaya/tambah', $data);
        $this->load->view('templateadmin/footer');
    }


    public function simpan(){
			$tr = new Tabledx;
			$tr->table($this->table1);
			$tr->getInput();
			$produk = $tr->postget['databarangpembelian'];
			unset($tr->postget['databarangpembelian']);
			var_dump($produk);
			$tr->postget['data_biaya'] = json_encode($produk);
			$tr->addUpdated();
			$tr->newData();
            redirect('admin/biaya');
    }

    public function update(){
        $tr = new Tabledx;
        $tr->table($this->table1);
        $tr->getInput();
        $produk = $tr->postget['databarangpembelian'];
        unset($tr->postget['databarangpembelian']);
        var_dump($produk);
        $tr->postget['data_biaya'] = json_encode($produk);
        $tr->condition([
            'id' => post('id')
        ]);
        $tr->addUpdated();
        $tr->updateData();
        redirect('admin/biaya');
    }

    public function exls(array $data = [], array $headers = [], $fileName = 'data-biaya.xlsx')
    {
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        $headers = ["No","Akun Pembayaran","Penerima","Tanggal Transaksi","Cara Pembayaran","No Biaya","Tag","Alamat","Data Biaya","Memo","Lampiran","Tanggal Dibuat","Tanggal Diupdate", "action"];

        $calldata = ["akun_pembayaran","Penerima","tanggal_transaksi","cara_pembayaran","no_biaya","tag","alamat","data_biaya","memo","lampiran","created_at","updated_at"];

        for ($i = 0, $l = sizeof($headers); $i < $l; $i++) {
            $sheet->setCellValueByColumnAndRow($i + 1, 1, $headers[$i]);
        }

        $qr = $this->db->query("SELECT * FROM $this->table1")->result();

        foreach($qr as $i => $vv){
            $j = 1;
            $sheet->setCellValueByColumnAndRow(0 + 1, ($i + 1 + 1), $i + 1);
            foreach ($calldata as $k => $v) { // column $j
                $sheet->setCellValueByColumnAndRow($j + 1, ($i + 1 + 1), $vv->$v);
                $j++;
            }
        }

        $writer = new Xlsx($spreadsheet);
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="'. urlencode($fileName).'"');
        $writer->save('php://output');

    }

		public function temp($urutan)
    {
        $data['urutan'] = $urutan;
        $this->load->view('admin/biaya/temp', $data);
    }

}
