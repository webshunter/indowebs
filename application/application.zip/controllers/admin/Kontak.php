<?php
defined('BASEPATH') OR exit('No direct script access allowed');

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class Kontak extends CI_Controller {

	private $table1 = 'kontak';

	public function __construct()
	{
		parent::__construct();
        Cek_login::ceklogin();
		$this->load->model('Tabledx');
		$this->load->model('Createtable');
		$this->load->model('Datatable_gugus');
	}

	public function index()
	{
        $this->Createtable->location('admin/kontak/table_show');
        $this->Createtable->table_name('tableku');
        $this->Createtable->create_row(["No","Nama","Nama Perusahaan","Alamat","Email", "No Handphone", "action"]);
        $this->Createtable->order_set('0, 6');
		$show = $this->Createtable->create();

		$data['datatable'] = $show;
        $this->load->view('templateadmin/head');
        $this->load->view('admin/kontak/view', $data);
        $this->load->view('templateadmin/footer');
	}

    public function dtb()
    {
        $this->load->view('templateadmin/head');
        $this->load->view('datatable/kontak');
        $this->load->view('templateadmin/footer');
    }

	public function table_show($action = 'show', $keyword = '')
	{
		if ($action == "show") {

            if (isset($_POST['order'])): $setorder = $_POST['order']; else: $setorder = ''; endif;

            $typek = null;

            if($keyword == ''){
                $typek = $this->db->query("SELECT * FROM tipekontak ")->row()->id;
            }else{
                $typek = $keyword;
            }

            $this->Datatable_gugus->datatable(
                [
                    "table" => $this->table1,
                    "select" => [
											"*"
										],
                    'where' => [
                        ['tipe_kontak', 'LIKE', '%:\"'.$typek.'\"%'],
                        ['delete_set', '=', '0'],
                    ],
                    'limit' => [
                        'start' => post('start'),
                        'end' => post('length')
                    ],
                    'search' => [
                        'value' => $this->Datatable_gugus->search(),
                        'row' => ["nama_panggilan","nama_perusahaan","alamat_pengirim","email","handphone"]
                    ],
                    'table-draw' => post('draw'),
                    'table-show' => [
                        'key' => 'id',
                        'data' => ["nama_panggilan","nama_perusahaan","alamat_pengirim","email","handphone"]
                    ],
                    "action" => "standart",
                    'order' => [
                        'order-default' => ['id', 'ASC'],
                        'order-data' => $setorder,
                        'order-option' => [ "1"=>"nama_panggilan", "2"=>"nama_perusahaan", "3"=>"alamat_pengirim", "4"=>"email", "5"=>"handphone"],
                    ]
                ]
            );
            $this->Datatable_gugus->table_show();
        }elseif ($action == "update") {
            $data_row = $this->db->query("SELECT * FROM ".$this->table1." WHERE id = '".$keyword."'")->row();
            $data['form_data'] = $data_row;
            $this->load->view('templateadmin/head');
            $this->load->view('admin/kontak/edit', $data);
            $this->load->view('templateadmin/footer');
        }elseif ($action == "delete") {
            $hapus_data = $this->db->query("UPDATE ".$this->table1." SET delete_set = '1' WHERE id = '".post("id")."'");
        }
    }

    public function tambah_data()
    {
        $this->load->view('templateadmin/head');
        $this->load->view('admin/kontak/tambah');
        $this->load->view('templateadmin/footer');
    }


    public function simpan(){
        $tr = new Tabledx;

        $tr->table($this->table1);

        $tr->getInput();

        $produk = $tr->postget['bank'];

        unset($tr->postget['bank']);

        $tr->postget['tipe_kontak'] = json_encode($tr->postget['tipe_kontak']);
        $tr->postget['bank'] = strigToBinary(json_encode($produk));
        // input disimpan pertamakali
        $tr->addUpdated();

        $tr->newData();

        $idlast = $tr->getLast()->id;
        // input disimpan kedua
        foreach($produk as $key => $elf){
            $elf['kontak_id'] = $idlast;
            $tr = new Tabledx;
            $tr->table('databank');
            $tr->getInput($elf);
            $tr->addUpdated();
            $tr->newData();
        }

        redirect('admin/kontak');

    }

    public function update(){
        $tr = new Tabledx;
        $tr->table($this->table1);
        $tr->getInput();
        $produk = $tr->postget['bank'];
        unset($tr->postget['bank']);
        $tr->postget['tipe_kontak'] = json_encode($tr->postget['tipe_kontak']);
        $tr->postget['bank'] = strigToBinary(json_encode($produk));
        $tr->addUpdated();

        $tr->setToUpdate();

        $dd = binaryToArray($tr->row()->bank);

        $tr->updateData();

        $tr = new Tabledx;

        $tr->table('databank');

        $tr->condition([
            'kontak_id' => post('id')
        ]);

        $tr->delData();

        foreach($produk as $key => $elf){
            $elf['kontak_id'] = post('id');
            $tr = new Tabledx;
            $tr->table('databank');
            $tr->getInput($elf);
            $tr->addUpdated();
            $tr->newData();
        }

        redirect('admin/kontak');

    }

    public function exls($id = NULL, array $data = [], array $headers = [], $fileName = 'data-kontak.xlsx')
    {
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        $headers = ["no","nama panggilan","nama perusahaan","alamat pengirim","email","handphone"];

        $calldata = ["nama_panggilan","nama_perusahaan","alamat_pengirim","email","handphone"];

        for ($i = 0, $l = sizeof($headers); $i < $l; $i++) {
            $sheet->setCellValueByColumnAndRow($i + 1, 1, $headers[$i]);
        }

				$tr = new Tabledx;

				$tr->table($this->table1);

				$tr->select(" nama_panggilan, nama_perusahaan, alamat_pengirim, email, handphone ");

				$tr->condition([
					"tipe_kontak" => [
						"opsi" => "LIKE",
						"val" => '%:\"'.$id.'\"%'
                    ],
                    "delete_set" => '0'
				]);

        foreach($tr->getResult() as $i => $vv){
            $j = 1;
            $sheet->setCellValueByColumnAndRow(0 + 1, ($i + 1 + 1), $i + 1);
            foreach ($calldata as $k => $v) { // column $j
                $sheet->setCellValueByColumnAndRow($j + 1, ($i + 1 + 1), $vv->$v);
                $j++;
            }
        }

        $writer = new Xlsx($spreadsheet);
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="'. urlencode($fileName).'"');
        $writer->save('php://output');

    }


    public function api($id = null)
    {
        echo json_encode($this->db->query("SELECT * FROM $this->table1 WHERE id = '$id' ")->row());
    }

    public function temp($urutan)
    {
        $data['urutan'] = $urutan;
        $this->load->view('admin/kontak/temp', $data);
    }

}
