<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pajak extends CI_Controller {

	private $table1 = 'pajak';

	public function __construct()
	{
		parent::__construct();
        Cek_login::ceklogin();
		$this->load->model('Createtable');
		$this->load->model('Datatable_gugus');
	}

	public function index()
	{
        $this->Createtable->location('admin/pajak/table_show');
        $this->Createtable->table_name('tableku');
        $this->Createtable->create_row(["no","Pajak","Nama","Persentase Efektif","Pemotongan","Akun Pajak Penjualan","Akun Pajak Pembelian", "#"]);
        $this->Createtable->order_set('0, 7');
		$show = $this->Createtable->create();

		$data['datatable'] = $show;
        $this->load->view('templateadmin/head');
        $this->load->view('admin/pajak/view', $data);
        $this->load->view('templateadmin/footer');
	}

	public function table_show($action = 'show', $keyword = '')
	{
		if ($action == "show") {

            if (isset($_POST['order'])): $setorder = $_POST['order']; else: $setorder = ''; endif;

            $this->Datatable_gugus->datatable(
                [
                    "table" => $this->table1,
                    "select" => [
						"*"
					],
                    'where' => [
                        ['delete_set', '=', '0']
                    ],
                    'limit' => [
                        'start' => post('start'),
                        'end' => post('length')
                    ],
                    'search' => [
                        'value' => $this->Datatable_gugus->search(),
                        'row' => ["pajak","nama","persentase_efektif","pemotongan","akun_pajak_penjualan","akun_pajak_pembelian","created_at","updated_at"]
                    ],
                    'table-draw' => post('draw'),
                    'table-show' => [
                        'key' => 'id',
                        'data' => ["pajak","nama","persentase_efektif","pemotongan","akun_pajak_penjualan","updated_at"]
                    ],
                    "action" => "standart",
                    'order' => [
                        'order-default' => ['id', 'ASC'],
                        'order-data' => $setorder,
                        'order-option' => [ "1"=>"pajak", "2"=>"nama", "3"=>"persentase_efektif", "4"=>"pemotongan", "5"=>"akun_pajak_penjualan", "6"=>"akun_pajak_pembelian", "7"=>"created_at", "8"=>"updated_at", "9"=>"delete_set"],
                    ],

                ]
            );
            $this->Datatable_gugus->table_show();
        }elseif ($action == "update") {
            $data_row = $this->db->query("SELECT * FROM ".$this->table1." WHERE id = '".$keyword."'")->row();
            $data['form_data'] = $data_row;
            $this->load->view('templateadmin/head');
            $this->load->view('admin/pajak/edit', $data);
            $this->load->view('templateadmin/footer');
        }elseif ($action == "delete") {
            $hapus_data = $this->db->query("UPDATE ".$this->table1." SET delete_set = '1' WHERE id = '".post("id")."'");
        }
    }

    public function tambah_data()
    {
        $this->load->view('templateadmin/head');
        $this->load->view('admin/pajak/tambah');
        $this->load->view('templateadmin/footer');
    }


    public function simpan(){
        $pajak = post("pajak");
$nama = post("nama");
$persentase_efektif = post("persentase_efektif");
$pemotongan = post("pemotongan");
$akun_pajak_penjualan = post("akun_pajak_penjualan");
$akun_pajak_pembelian = post("akun_pajak_pembelian");



        $simpan = $this->db->query("
            INSERT INTO pajak
            (pajak,nama,persentase_efektif,pemotongan,akun_pajak_penjualan,akun_pajak_pembelian) VALUES ('$pajak','$nama','$persentase_efektif','$pemotongan','$akun_pajak_penjualan','$akun_pajak_pembelian')
        ");


        if($simpan){
            redirect('admin/pajak');
        }
    }

    public function update(){
          $key = post('id'); $pajak = post("pajak");
$nama = post("nama");
$persentase_efektif = post("persentase_efektif");
$pemotongan = post("pemotongan");
$akun_pajak_penjualan = post("akun_pajak_penjualan");
$akun_pajak_pembelian = post("akun_pajak_pembelian");

        $simpan = $this->db->query("
            UPDATE pajak SET  pajak = '$pajak', nama = '$nama', persentase_efektif = '$persentase_efektif', pemotongan = '$pemotongan', akun_pajak_penjualan = '$akun_pajak_penjualan', akun_pajak_pembelian = '$akun_pajak_pembelian' WHERE id = '$key'
            ");


        if($simpan){
            redirect('admin/pajak');
        }
    }

    public function api($id = null)
    {
        echo json_encode($this->db->query("SELECT * FROM $this->table1 WHERE id = '$id' ")->row());
    }


}
