<?php
defined('BASEPATH') OR exit('No direct script access allowed');

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class Penjualan extends CI_Controller {

	private $table1 = 'penjualan';

	public function __construct()
	{
		parent::__construct();
        Cek_login::ceklogin();
		$this->load->model('Tabledx');
		$this->load->model('Createtable');
		$this->load->model('Datatable_gugus');
	}

	public function index()
	{
        $this->Createtable->location('admin/penjualan/table_show');
        $this->Createtable->table_name('tableku');
        $this->Createtable->create_row(["No","No Nota","Tanggal","Termin (hari)","Jatuh Tempo","Kode Supplier","Nama","Alamat","Ongkir","Pembayaran", "action"]);
        $this->Createtable->order_set('0, 10');
		$show = $this->Createtable->create();

		$data['datatable'] = $show;
        $this->load->view('templateadmin/head');
        $this->load->view('admin/penjualan/view', $data);
        $this->load->view('templateadmin/footer');
	}

	public function table_show($action = 'show', $keyword = '')
	{
		if ($action == "show") {

            if (isset($_POST['order'])): $setorder = $_POST['order']; else: $setorder = ''; endif;

            $this->Datatable_gugus->datatable(
                [
                    "table" => $this->table1,
                    "select" => [
						"*"
					],
                    'where' => [
                        ['delete_set', '=', '0']
                    ],
                    'limit' => [
                        'start' => post('start'),
                        'end' => post('length')
                    ],
                    'search' => [
                        'value' => $this->Datatable_gugus->search(),
                        'row' => ["no_nota","tanggal","termin","jatuh_tempo","kode","nama","alamat","ongkir","pembayaran","created_at","updated_at"]
                    ],
                    'table-draw' => post('draw'),
                    'table-show' => [
                        'key' => 'id',
                        'data' => ["no_nota","tanggal","termin","jatuh_tempo","kode","nama","alamat","ongkir","pembayaran", "id"]
                    ],
                    "action" => "standart",
                    'order' => [
                        'order-default' => ['id', 'ASC'],
                        'order-data' => $setorder,
                        'order-option' => [ "1"=>"no_nota", "2"=>"tanggal", "3"=>"termin", "4"=>"jatuh_tempo", "5"=>"kode", "6"=>"nama", "7"=>"alamat", "8"=>"ongkir", "9"=>"pembayaran", "10"=>"created_at", "11"=>"updated_at", "12"=>"delete_set"],
                    ],
                    "custome" => [
                        "kode" => [
                            "replacerow" => [
                                "table" => "kontak",
                                "condition" => ['id'],
                                "value" => ['kode'],
                                "get" => "kode",
                            ],
                        ],
                        "termin" => [
                            "replacerow" => [
                                "table" => "termin",
                                "condition" => ['id'],
                                "value" => ['termin'],
                                "get" => "pilihan",
                            ],
                        ],
                        "ongkir" => [
                            "key" => ['ongkir'],
                            "content" => "
                                <span style=\"float: right;\" class=\"ongkir\">{{ongkir}}</span>
                            ",
                        ],
                        "pembayaran" => [
                            "key" => ['pembayaran'],
                            "content" => "
                                <span style=\"float: right;\" class=\"pembayaran\">{{pembayaran}}</span>
                            ",
                        ],
                        "id" => [
                            "key" => ['id'],
                            "content" => "
                                <div class=\"dropdown\">
                                    <button class=\"btn btn-primary dropdown-toggle\" type=\"button\" id=\"dropdownMenuButton{{id}}\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
                                        Setting
                                    </button>
                                    <div class=\"dropdown-menu\" aria-labelledby=\"dropdownMenuButton{{id}}\">
                                        <a data-id='{{id}}' class=\"dropdown-item edit\" href=\"#\"><i class='fas fa-edit'></i> Ubah</a>
                                        <a data-id='{{id}}' class=\"dropdown-item delete\" href=\"#\"><i class='fas fa-trash'></i> hapus</a>
                                        <a class=\"dropdown-item\" href=\"{{site_url}}admin/penjualan/cetakStruk/{{id}}\"><i class='fas fa-file-pdf'></i> cetak faktur</a>
                                    </div>
                                </div>

                            ",
                        ],
                    ]

                ]
            );
            $this->Datatable_gugus->table_show();
        }elseif ($action == "update") {
            $data_row = $this->db->query("SELECT * FROM ".$this->table1." WHERE id = '".$keyword."'")->row();
            $data['form_data'] = $data_row;
            $this->load->view('templateadmin/head');
            $this->load->view('admin/penjualan/edit', $data);
            $this->load->view('templateadmin/footer');
        }elseif ($action == "delete") {
            $hapus_data = $this->db->query("UPDATE ".$this->table1." SET delete_set = '1' WHERE id = '".post("id")."'");
        }
    }

    public function tambah_data()
    {

			// autoNUmber
			$tr = new Tabledx;
			$tr->table($this->table1);
			$tr->condition([
				"no_nota" => [
					'opsi' => "LIKE",
					'val' => 'PJ'.date('ym').'%',
				]
			]);
			$x = $tr->num_rows() + 1;
			$code = "PJ".date('ym');
			$code2 = str_pad($x, 5, '0', STR_PAD_LEFT);
			$data['code'] = $code.'-'.$code2;

        $this->load->view('templateadmin/head');
        $this->load->view('admin/penjualan/tambah', $data);
        $this->load->view('templateadmin/footer');
    }


    public function simpan(){

        $tr = new Tabledx;

        $tr->table($this->table1);

        $tr->getInput();

        $produk = $tr->postget['databarangpembelian'];

        unset($tr->postget['databarangpembelian']);

        // input disimpan pertamakali
        $tr->addUpdated();

        $tr->newData();

        $idlast = $tr->getLast()->id;
        // input disimpan kedua
        foreach($produk as $key => $elf){
            $elf['pembelian_id'] = $idlast;
            $tr = new Tabledx;
            $tr->table('datapenjualan');
            $tr->getInput($elf);
            $tr->addUpdated();
            $tr->newData();
        }


        return redirect('admin/penjualan');

    }

    public function update(){
          $tr = new Tabledx;

        $tr->table($this->table1);

        $tr->getInput();

        $produk = $tr->postget['databarangpembelian'];

        unset($tr->postget['databarangpembelian']);

        // input disimpan pertamakali
        $tr->addUpdated();

        $tr->setToUpdate();

        $tr->updateData();

        $tr = new Tabledx;

        $tr->table('datapenjualan');

        $tr->condition([
            'pembelian_id' => post('id')
        ]);

        $tr->delData();

        foreach($produk as $key => $elf){
            $elf['pembelian_id'] = post('id');
            $tr = new Tabledx;
            $tr->table('datapenjualan');
            $tr->getInput($elf);
            $tr->addUpdated();
            $tr->newData();
        }

        return redirect('admin/penjualan');
    }

    public function exls(array $data = [], array $headers = [], $fileName = 'data-pembelian.xlsx')
    {
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        $headers = ["No","No Nota","Tanggal","Termin","Jatuh Tempo","Kode","Nama","Alamat","Ongkir","Pembayaran","Tanggal Dibuat","Tanggal Diupdate", "action"];

        $calldata = ["no_nota","tanggal","termin","jatuh_tempo","kode","nama","alamat","ongkir","pembayaran","created_at","updated_at"];

        for ($i = 0, $l = sizeof($headers); $i < $l; $i++) {
            $sheet->setCellValueByColumnAndRow($i + 1, 1, $headers[$i]);
        }

        $qr = $this->db->query("SELECT * FROM $this->table1 WHERE delete_set = '0' ")->result();

        foreach($qr as $i => $vv){
            $j = 1;
            $sheet->setCellValueByColumnAndRow(0 + 1, ($i + 1 + 1), $i + 1);
            foreach ($calldata as $k => $v) { // column $j
                $sheet->setCellValueByColumnAndRow($j + 1, ($i + 1 + 1), $vv->$v);
                $j++;
            }
        }

        $writer = new Xlsx($spreadsheet);
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="'. urlencode($fileName).'"');
        $writer->save('php://output');

    }

    public function temp($urutan)
    {
        $data['urutan'] = $urutan;
        $this->load->view('admin/penjualan/temp', $data);
    }

    public function cetakStruk($id = null)
    {
        $logo = FCPATH.cek(Perusahaans::get(),'logo');
        $perus = cek(Perusahaans::get(),'nama');
        $alamat = cek(Perusahaans::get(),'alamat');
        $hp = cek(Perusahaans::get(),'hp');


        $td = new Tabledx;

        $td->table('penjualan');

        $td->condition([
            'id' => $id
        ]);

        $td = $td->row();

				require_once 'phpqrcode/qrlib.php';

				// qr generator

				$text = $td->alamat;

				//file path
				$file = FCPATH."qr1.png";

				//other parameters
				$ecc = 'H';
				$pixel_size = 20;
				$frame_size = 5;

				// Generates QR Code and Save as PNG
				QRcode::png($text, $file, $ecc, $pixel_size, $frame_size);

				// end qr generator

        $kontak = new Tabledx;

        $kontak->table('kontak');

        $kontak->condition([
            'id' => $td->kode
        ]);

        $kontak = $kontak->row();



        $datap = new Tabledx;

        $datap->table('datapenjualan');

        $datap->condition([
            'pembelian_id' => $td->id
        ]);

        $datap = $datap->getResult();

        $table = "";

        $jmlitem = count($datap);

        $totpot = 0;

        $pajak = 0;

        if ($td->pajak == 1) {
            $pajak = 10 / 100;
        }

        $totjml = 0;

        $terbilang = terbilang($td->total);

        foreach ($datap as $key => $value) {
            $no = $key + 1;

            $produk = new Tabledx;

            $produk->table('produk');

            $produk->condition([
                'id' => $value->produk
            ]);

            $produk = $produk->row();

            $harga = rupiah($value->harga);

            $pot = rupiah($value->harga * ($value->diskon / 100));

            $totpot += $value->harga * ($value->diskon / 100);

            $jml = rupiah($value->jumlah);

            $totjml += $value->jumlah;

						$kode = "";
						if(isset($produk->kode)){
							$kode = $produk->kode;
						}

						$nama = "";
						if(isset($produk->nama)){
							$nama = $produk->nama;
						}

						$kontakkode = "";
						if(isset($kontak->kode)){
							$kontakkode = $kontak->kode;
						}

						$kontaknama_awal = "";
						if(isset($kontak->nama_awal)){
							$kontaknama_awal = $kontak->nama_awal;
						}


            $table .= "

                <tr>
                    <td style='text-align: center;' width='20mm'>
                        $no
                    </td>
                    <td style='text-align: center;' width='30mm'>
                        $kode
                    </td>
                    <td style='text-align: center;' width='50mm'>
                        $nama
                    </td>
                    <td style='text-align: center;' width='30mm'>
                        $value->qty
                    </td>
                    <td style='text-align: center;' width='40mm'>
                        Rp. $harga
                    </td>
                    <td style='text-align: center;' width='40mm'>
                        Rp. $pot
                    </td>
                    <td style='text-align: center;'>
                        Rp. $jml
                    </td>
                </tr>

            ";
        }

        $totpot = rupiah($totpot);

        $totjml = rupiah($totjml * $pajak);

        $mpdf = new \Mpdf\Mpdf(['orientation'=>'L']);
        $mpdf->WriteHTML("
            <table width='100%'>
                <tr>
                    <td width='110mm'>
                        <table>
                            <tr>
                                <td>
                                    <img height=\"100px\" src='$logo' />
                                </td>
                                <td>
                                    <table>
                                        <tr>
                                            <td style='font-size: 20px;font-weight: bold;'>FAKTUR PENJUALAN</td>
                                        </tr>
                                        <tr>
                                            <td style='font-size: 18px;font-weight: bold;'>$perus</td>
                                        </tr>
                                        <tr>
                                            <td>$alamat</td>
                                        </tr>
                                        <tr>
                                            <td>$hp</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </td>
                    <td>
                        <table width='100%'>
                            <tr>
                                <td width='50%'>
                                    <table>
                                        <tr>
                                            <td>
                                               No Transaksi
                                            </td>
                                            <td>
                                                :
                                            </td>
                                            <td>
                                                $td->no_nota
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                               Tanggal
                                            </td>
                                            <td>
                                                :
                                            </td>
                                            <td>
                                                ".format_tanggal($td->tanggal)."
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                               Kode Sales
                                            </td>
                                            <td>
                                                :
                                            </td>
                                            <td>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                               Pelanggan
                                            </td>
                                            <td>
                                                :
                                            </td>
                                            <td>
                                                $kontaknama_awal
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                               Alamat
                                            </td>
                                            <td>
                                                :
                                            </td>
                                            <td>
                                                $td->alamat
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                                <td width='50%'>
                                    <table>
                                        <tr>
                                            <td>
                                                Dept.
                                            </td>
                                            <td>
                                               :
                                            </td>
                                            <td>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                User
                                            </td>
                                            <td>
                                               :
                                            </td>
                                            <td>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                Qr Code
                                            </td>
                                            <td>
                                               :
                                            </td>
                                            <td>
																							<img width='30mm' src='$file' />
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                Code Cutomer
                                            </td>
                                            <td>
                                               :
                                            </td>
                                            <td>
                                                $kontakkode
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
            <table width='100%' style='border-top: 1px solid black; border-bottom: 2px solid black;font-weight: bold;'>
                <tr>
                    <td style='text-align: center;' width='20mm'>
                        No.
                    </td>
                    <td style='text-align: center;' width='30mm'>
                        Kode Item
                    </td>
                    <td style='text-align: center;' width='50mm'>
                        Nama Item
                    </td>
                    <td style='text-align: center;' width='30mm'>
                        Jml Satuan
                    </td>
                    <td style='text-align: center;' width='40mm'>
                        Harga
                    </td>
                    <td style='text-align: center;' width='40mm'>
                        Pot
                    </td>
                    <td style='text-align: center;'>
                        total
                    </td>
                </tr>
            </table>
            <table width='100%' style='border-top: 3px solid black; margin-top: 2px; padding-top: 5px;'>
                $table
            </table>
            <table width='100%'>
                <tr>
                    <td width='50%'>
                        <table>
                            <tr>
                                <td>Keterangan :</td>
                                <td>$td->keterangan</td>
                            </tr>
                        </table>
                        <br>
                        <table width='100%' style='text-align: center;'>
                            <tr>
                                <td width='50%'>Hormat Kami</td>
                                <td width='50%'>Penerima</td>
                            </tr>
                            <tr>
                                <td width='50%' height='100px'></td>
                                <td width='50%'></td>
                            </tr>
                            <tr>
                                <td width='50%'>(.................................)</td>
                                <td width='50%'>(.................................)</td>
                            </tr>
                        </table>
                    </td>
                    <td width='50%'>
                        <table width='100%'>
                            <tr>
                                <td width='50%'>
                                    <table>
                                        <tr>
                                            <td>Jml Item</td><td>:</td><td>$jmlitem</td>
                                        </tr>
                                        <tr>
                                            <td>Potongan</td><td>:</td><td>Rp. $totpot</td>
                                        </tr>
                                        <tr>
                                            <td>Pajak</td><td>:</td><td>Rp $totjml</td>
                                        </tr>
                                        <tr>
                                            <td>Biaya Lain</td><td>:</td><td>-</td>
                                        </tr>
                                        <tr>
                                            <td>Tanggal Jt</td><td>:</td><td>$td->jatuh_tempo</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                                <td width='50%'>
                                    <table>
                                        <tr>
                                            <td>Sub Total</td><td>:</td><td>Rp ".rupiah($td->subtotal)."</td>
                                        </tr>
                                        <tr>
                                            <td>Total Akhir</td><td>:</td><td>Rp ".rupiah($td->total)."</td>
                                        </tr>
                                        <tr>
                                            <td>DP PO</td><td>:</td><td>Rp 0</td>
                                        </tr>
                                        <tr>
                                            <td>Tunai</td><td>:</td><td>Rp ".rupiah($td->pembayaran)."</td>
                                        </tr>
                                        <tr>
                                            <td>Kredit</td><td>:</td><td>Rp 0</td>
                                        </tr>
                                        <tr>
                                            <td>Kembalian</td><td>:</td><td>Rp 0</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr style='margin-top: 20px;'>
                    <td colspan='2'>
                        <table>
                            <tr>
                                <td>Terbilang :</td>
                                <td>$terbilang rupiah</td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        ");
        $mpdf->output();
    }

    public function qr()
    {
        $qrCode = new QrCode('Lorem ipsum sit dolor');

        $output = new Output\Png();

        // Save black on white PNG image 100px wide to filename.png
        $output->output($qrCode, 100, [255, 255, 255], [0, 0, 0], 'filename.png');
    }

}
