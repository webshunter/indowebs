<?php
defined('BASEPATH') OR exit('No direct script access allowed');

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class Produk extends CI_Controller {

	private $table1 = 'produk';

	public function __construct()
	{
		parent::__construct();
    Cek_login::ceklogin();
		$this->load->model('Importxls');
		$this->load->model('Tabledx');
		$this->load->model('Createtable');
		$this->load->model('Datatable_gugus');
	}

	public function index()
	{
				$data['stokbarang'] = $this->stoktersedia();
				$data['stokbaranghabis'] = $this->stoktersediahabis();
				$data['daftargudang'] = $this->daftargudang();
        $this->Createtable->location('admin/produk/table_show');
        $this->Createtable->table_name('tableku');
        $this->Createtable->create_row(["no","Kode Produk","Nama","qty", "Batas Minimum","Unit","Harga Rata Rata", "Harga Beli Terakhir", "Harga Beli", "Harga Jual", "Kategori Produk","action"]);
        $this->Createtable->order_set('0, 11');
				$show = $this->Createtable->create();
				$data['datatable'] = $show;
        $this->load->view('templateadmin/head');
        $this->load->view('admin/produk/view', $data);
        $this->load->view('templateadmin/footer');
	}


	public function stoktersedia()
	{
		$tr = new Tabledx;
		$tr->table($this->table1);
		$tr->select(" DISTINCT nama ");
		return $tr->num_rows();
	}

	public function stoktersediahabis()
	{
		$tr = new Tabledx;
		$tr->table($this->table1);
		$tr->select(" DISTINCT nama ");
		return $tr->num_rows();
	}

	public function daftargudang()
	{
		$tr = new Tabledx;
		$tr->table('gudang');
		return $tr->num_rows();
	}

	public function table_show($action = 'show', $keyword = '')
	{
		if ($action == "show") {

            if (isset($_POST['order'])): $setorder = $_POST['order']; else: $setorder = ''; endif;

            $this->Datatable_gugus->datatable(
                [
                    "table" => $this->table1,
                    "select" => [
						"*"
					],
                    'where' => [
                        ['delete_set', '=', '0']
                    ],
                    'limit' => [
                        'start' => post('start'),
                        'end' => post('length')
                    ],
                    'search' => [
                        'value' => $this->Datatable_gugus->search(),
                        'row' => ["nama","kode","kategori","unit","deskripsi","jenis_barang","barcode","harga_beli","akun_pembelian","pajak_pembelian","harga_jual","akun_penjualan","pajak_jual","batas_stok","akun_stok","bundle_id","created_at","updated_at"]
                    ],
                    'table-draw' => post('draw'),
                    'table-show' => [
                        'key' => 'id',
                        'data' => ["kode","nama","id","batas_stok","unit","akun_pembelian","akun_penjualan","harga_beli", "harga_jual", "kategori"]
                    ],
                    "action" => "standart",
                    'order' => [
                        'order-default' => ['id', 'ASC'],
                        'order-data' => $setorder,
                        'order-option' => [ "1"=>"gambar", "2"=>"nama", "3"=>"kode", "4"=>"kategori", "5"=>"unit", "6"=>"deskripsi", "7"=>"jenis_barang", "8"=>"barcode", "9"=>"harga_beli", "10"=>"akun_pembelian", "11"=>"pajak_pembelian", "12"=>"harga_jual", "13"=>"akun_penjualan", "14"=>"pajak_jual", "15"=>"batas_stok", "16"=>"akun_stok", "17"=>"bundle_id", "18"=>"created_at", "19"=>"updated_at", "20"=>"delete_set"],
                    ],
                    'custome' => [
                        "harga_jual" => [
                            "key" => ['harga_jual'],
                            "content" => "
                                <span style=\"float: right;\" class=\"hj\">{{harga_jual}}</span>
                            ",
                        ],
                        "harga_beli" => [
                            "key" => ['harga_beli'],
                            "content" => "
                                <span style=\"float: right;\" class=\"hb\">{{harga_beli}}</span>
                            ",
                        ],
                        "batas_stok" => [
                            "key" => ['batas_stok'],
                            "content" => "
                                <span style=\"float: right;\" class=\"bts\">{{batas_stok}}</span>
                            ",
                        ],
                        "akun_penjualan" => [
                            "key" => ['id'],
                            "content" => "
                                <span style=\"float: right;\" class=\"hbt\"></span>
                            ",
                        ],
                        "akun_pembelian" => [
                            "key" => ['id'],
                            "content" => "
                                <span style=\"float: right;\" class=\"hrr\"></span>
                            ",
                        ],
                        "id" => [
                            "key" => ['id'],
                            "content" => "
                                <span class=\"qty\"></span>
                            ",
                        ],
                        "unit" => [
                            "replacerow" => [
                                "table" => "satuan",
                                "condition" => ['id'],
                                "value" => ['unit'],
                                "get" => "satuan",
                            ],
                        ],
                        "kategori" => [
                            "replacerow" => [
                                "table" => "kategoriproduk",
                                "condition" => ['id'],
                                "value" => ['kategori'],
                                "get" => "pilihan",
                            ],
                        ],
                    ],
                ]
            );
            $this->Datatable_gugus->table_show();
        }elseif ($action == "update") {
            $data_row = $this->db->query("SELECT * FROM ".$this->table1." WHERE id = '".$keyword."'")->row();
            $data['form_data'] = $data_row;
            $this->load->view('templateadmin/head');
            $this->load->view('admin/produk/edit', $data);
            $this->load->view('templateadmin/footer');
        }elseif ($action == "delete") {
            $hapus_data = $this->db->query("UPDATE ".$this->table1." SET delete_set = '1' WHERE id = '".post("id")."'");
        }
    }

    public function tambah_data()
    {
        $this->load->view('templateadmin/head');
        $this->load->view('admin/produk/tambah');
        $this->load->view('templateadmin/footer');
    }


    public function simpan(){

        $tr = new Tabledx;

        $tr->table($this->table1);

        $tr->getInput();

        $tr->postget['gambar'] = Form::getfile("gambar", "assets/gambar/$this->table1/");

        $produk = $tr->postget['databarangpembelian'];

        unset($tr->postget['databarangpembelian']);

        $tr->postget['bundle_id'] = json_encode($produk);
        // input disimpan pertamakali
        $tr->addUpdated();

        $tr->newData();

        $idlast = $tr->getLast()->id;
        // input disimpan kedua
        foreach($produk as $key => $elf){
            $elf['produk_id'] = $idlast;
            $tr = new Tabledx;
            $tr->table('productbundle');
            $tr->getInput($elf);
            $tr->addUpdated();
            $tr->newData();
        }

        redirect('admin/produk');
    }

    public function update(){
          $key = post('id'); $gambar = Form::getfile("gambar", "assets/gambar/$this->table1/", $key, $this->table1);
$nama = post("nama");
$kode = post("kode");
$kategori = post("kategori");
$unit = post("unit");
$deskripsi = post("deskripsi");
$jenis_barang = post("jenis_barang");
$barcode = post("barcode");
$harga_beli = post("harga_beli");
$akun_pembelian = post("akun_pembelian");
$pajak_pembelian = post("pajak_pembelian");
$harga_jual = post("harga_jual");
$akun_penjualan = post("akun_penjualan");
$pajak_jual = post("pajak_jual");
$batas_stok = post("batas_stok");
$akun_stok = post("akun_stok");
$bundle_id = post("bundle_id");

        $simpan = $this->db->query("
            UPDATE produk SET  gambar = '$gambar', nama = '$nama', kode = '$kode', kategori = '$kategori', unit = '$unit', deskripsi = \"$deskripsi\", jenis_barang = '$jenis_barang', barcode = '$barcode', harga_beli = '$harga_beli', akun_pembelian = '$akun_pembelian', pajak_pembelian = '$pajak_pembelian', harga_jual = '$harga_jual', akun_penjualan = '$akun_penjualan', pajak_jual = '$pajak_jual', batas_stok = '$batas_stok', akun_stok = '$akun_stok', bundle_id = '$bundle_id' WHERE id = '$key'
            ");


        if($simpan){
            redirect('admin/produk');
        }
    }

    public function exls(array $data = [], array $headers = [], $fileName = 'data-produk.xlsx')
    {
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        $headers = ["no","Gambar","Nama","Kode","Kategori","Unit","Deskripsi","Jenis barang","Barcode","Harga Beli","Akun Pembelian","Pajak Beli","Harga Jual","Akun Penjualan","Pajak Jual","Batas Stok","Akun Stok","Bundle Id","tanggal dibuat","tanggal diupdate", "action"];

        $calldata = ["gambar","nama","kode","kategori","unit","deskripsi","jenis_barang","barcode","harga_beli","akun_pembelian","pajak_pembelian","harga_jual","akun_penjualan","pajak_jual","batas_stok","akun_stok","bundle_id","created_at","updated_at"];

        for ($i = 0, $l = sizeof($headers); $i < $l; $i++) {
            $sheet->setCellValueByColumnAndRow($i + 1, 1, $headers[$i]);
        }

        $qr = $this->db->query("SELECT * FROM $this->table1 WHERE delete_set = '0' ")->result();

        foreach($qr as $i => $vv){
            $j = 1;
            $sheet->setCellValueByColumnAndRow(0 + 1, ($i + 1 + 1), $i + 1);
            foreach ($calldata as $k => $v) { // column $j
                $sheet->setCellValueByColumnAndRow($j + 1, ($i + 1 + 1), $vv->$v);
                $j++;
            }
        }

        $writer = new Xlsx($spreadsheet);
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="'. urlencode($fileName).'"');
        $writer->save('php://output');

    }

    public function api($id = null)
    {
        echo json_encode($this->db->query("SELECT * FROM $this->table1 WHERE id = '$id' ")->row());
    }

    public function temp($urutan)
    {
        $data['urutan'] = $urutan;
        $this->load->view('admin/produk/temp', $data);
    }


		public function import()
		{

			$el = new Importxls;

			$el->get();

		}

}
