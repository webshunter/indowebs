<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	private $table1 = 'user';

	public function __construct()
	{
		parent::__construct();
    Cek_login::ceklogin();
		$this->load->model('Tabledx');
		$this->load->model('Createtable');
		$this->load->model('Datatable_gugus');
	}

	public function index()
	{
        $this->Createtable->location('admin/user/table_show');
        $this->Createtable->table_name('tableku');
        $this->Createtable->create_row(["no","Foto","Nama","Level","Username","Password","action"]);
        $this->Createtable->order_set('0, 6');
		$show = $this->Createtable->create();

		$data['datatable'] = $show;
        $this->load->view('templateadmin/head');
        $this->load->view('admin/user/view', $data);
        $this->load->view('templateadmin/footer');
	}

	public function table_show($action = 'show', $keyword = '')
	{
		if ($action == "show") {

            if (isset($_POST['order'])): $setorder = $_POST['order']; else: $setorder = ''; endif;

            $this->Datatable_gugus->datatable(
                [
                    "table" => $this->table1,
                    "select" => [
						"*"
					],
                    'where' => [
                        ['delete_set', '=', '0']
                    ],
                    'limit' => [
                        'start' => post('start'),
                        'end' => post('length')
                    ],
                    'search' => [
                        'value' => $this->Datatable_gugus->search(),
                        'row' => ["foto","nama","level","username","password","passwordview","created_at","updated_at"]
                    ],
                    'table-draw' => post('draw'),
                    'table-show' => [
                        'key' => 'id',
                        'data' => ["foto","nama","level","username","passwordview"]
                    ],
                    "action" => "standart",
                    'order' => [
                        'order-default' => ['id', 'ASC'],
                        'order-data' => $setorder,
                        'order-option' => [ "1"=>"foto", "2"=>"nama", "3"=>"level", "4"=>"username", "5"=>"password", "6"=>"passwordview", "7"=>"created_at", "8"=>"updated_at", "9"=>"delete_set"],
                    ],
                     'custome' => [

        "foto" => [
            "key" => ['foto'],
            "content" => "
            <img src='{{base_url}}assets/gambar/user/{{foto}}' style='width: 60px;' />
        ",
        ],

        "level" => [
            "replacerow" => [
				"table" => "leveluser",
				"condition" => ['id'],
				"value" => ['level'],
				"get" => "pilihan",
			],
        ],
    ],
                ]
            );
            $this->Datatable_gugus->table_show();
        }elseif ($action == "update") {
            $data_row = $this->db->query("SELECT * FROM ".$this->table1." WHERE id = '".$keyword."'")->row();
            $data['form_data'] = $data_row;
            $this->load->view('templateadmin/head');
            $this->load->view('admin/user/edit', $data);
            $this->load->view('templateadmin/footer');
        }elseif ($action == "delete") {
            $hapus_data = $this->db->query("UPDATE ".$this->table1." SET delete_set = '1' WHERE id = '".post("id")."'");
        }
    }

    public function tambah_data()
    {
        $this->load->view('templateadmin/head');
        $this->load->view('admin/user/tambah');
        $this->load->view('templateadmin/footer');
    }


    public function simpan(){
        $foto = Form::getfile("foto", "assets/gambar/$this->table1/");
				$nama = post("nama");
				$level = post("level");
				$username = post("username");
				$password = md5(md5(post("password")));
				$passwordview = post("passwordview");

				$s = new Tabledx;

				$s->table($this->table1);

				$s->condition([
					"username" => $username
				]);

				if($s->row() == NULL ){
					$simpan = $this->db->query("
					INSERT INTO user
					(foto,nama,level,username,password,passwordview) VALUES ('$foto','$nama','$level','$username','$password','$passwordview')
					");
					if($simpan){
						redirect('admin/user');
					}
				}else{
					pesan("Maaf username sudah digunakan");
					redirect('admin/user/tambah_data');
				}

    }

    public function update(){
          $key = post('id'); $foto = Form::getfile("foto", "assets/gambar/$this->table1/", $key, $this->table1);
					$nama = post("nama");
					$level = post("level");
					$username = post("username");
					$password = post("password");
            if($this->db->query("SELECT * FROM $this->table1 WHERE id = '$key'")->row()->password != post("password")){
                $password = md5(md5(post("$key")));
            }$password = md5(md5(post("password")));
$passwordview = post("passwordview");

        $simpan = $this->db->query("
            UPDATE user SET  foto = '$foto', nama = '$nama', level = '$level', username = '$username', password = '$password', passwordview = '$passwordview' WHERE id = '$key'
            ");


        if($simpan){
            redirect('admin/user');
        }
    }

}
