<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
        <div class="col-sm-6">
            <h1 class="m-0 text-dark">Ubah Daftar Akun</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="{{ url('toko') }}">Home</a></li>
            </ol>
        </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <section class="content">
      <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form action="<?= site_url('admin/akun/update') ?>" method="post" enctype="multipart/form-data">
                        
        <?=
            form::input([
                "type" => "hidden",
                "fc" => "id",
                "value" => $form_data->id,
            ])
        ?>
    
                <?=
                    form::input([
                        "title" => "Kunci",
                        "type" => "hidden",
                        "fc" => "kunci",
                        "placeholder" => "tambahkan kunci",
                        "value" => $form_data->kunci,
                    ])
                ?>
            
                <?=
                    form::input([
                        "title" => "Kode Akun",
                        "type" => "text",
                        "fc" => "kode_akun",
                        "placeholder" => "tambahkan kode_akun",
                        "value" => $form_data->kode_akun,
                    ])
                ?>
            
                <?=
                    form::input([
                        "title" => "Nama Akun",
                        "type" => "text",
                        "fc" => "nama_akun",
                        "placeholder" => "tambahkan nama_akun",
                        "value" => $form_data->nama_akun,
                    ])
                ?>
            
                <?=
                    form::select_db([
                        "title" => "Kategori Akun",
                        "type" => "password",
                        "fc" => "kategori_akun_id",
                        "placeholder" => "tambahkan kategori_akun_id",
                        "db" => "kategoriakun",
                        "data" => "id",
                        "name" => "kategori",
                        "selected" => $form_data->kategori_akun_id,
                    ])
                ?>
            
                <?=
                    form::select_db([
                        "title" => "Pajak",
                        "type" => "password",
                        "fc" => "pajak",
                        "placeholder" => "tambahkan pajak",
                        "db" => "pajak",
                        "data" => "id",
                        "name" => "nama",
                        "selected" => $form_data->pajak,
                    ])
                ?>
            
                <?=
                    form::input([
                        "title" => "Saldo",
                        "type" => "text",
                        "fc" => "saldo",
                        "placeholder" => "tambahkan saldo",
                        "value" => $form_data->saldo,
                    ])
                ?>
            
                <?=
                    form::editor([
                        "title" => "Deskripsi",
                        "type" => "text",
                        "fc" => "deskripsi",
                        "placeholder" => "tambahkan deskripsi",
                        "value" => $form_data->deskripsi,
                    ])
                ?>
            
                        <div class="form-group">
                          <button type="submit" class="btn btn-primary">Simpan</button>
                          <a class="btn btn-default" href="<?= site_url('admin/akun'); ?>">Back</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
      </div>
    </section>
</div>

