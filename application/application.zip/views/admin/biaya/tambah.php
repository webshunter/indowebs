<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
        <div class="col-sm-6">
            <h1 class="m-0 text-dark">Tambahkan Biaya</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
            </ol>
        </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <section class="content">
      <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form action="<?= site_url('admin/biaya/simpan') ?>" method="post" enctype="multipart/form-data">
                <div class="row">
                  <div class="col-sm-4">
                    <?=
                    form::input([
                      "title" => "No Biaya",
                      "type" => "text",
                      "readonly" => true,
                      "fc" => "no_biaya",
                      "placeholder" => "tambahkan no_biaya",
                      "value" => $code
                    ])
                    ?>
                  </div>
                  <div class="col-sm-4">
                    <?=
                    form::select_db([
                      "title" => "Akun Pembayaran",
                      "type" => "password",
                      "fc" => "akun_pembayaran",
                      "placeholder" => "tambahkan akun_pembayaran",
                      "db" => "akun",
                      "data" => "id",
                      "key" => ["nama_akun", "kode_akun"],
                      "custome" => "({{kode_akun}}) - {{nama_akun}}",
                    ])
                    ?>
                  </div>
                  <div class="col-sm-4">
                    <?=
                    form::input([
                      "title" => "Penerima",
                      "type" => "text",
                      "fc" => "penerima",
                      "placeholder" => "tambahkan Penerima",
                    ])
                    ?>
                  </div>
                </div>

                <div class="row">
                    <div class="col-sm-4">
                      <?=
                      form::input([
                        "title" => "Tanggal Transaksi",
                        "type" => "date",
                        "fc" => "tanggal_transaksi",
                        "placeholder" => "tambahkan tanggal_transaksi",
                        "value" => date('Y-m-d')
                      ])
                      ?>
                    </div>
                    <div class="col-sm-4">
                      <?=
                          form::input([
                              "title" => "Tag",
                              "type" => "text",
                              "fc" => "tag",
                              "tag" => true,
                              "placeholder" => "tambahkan tag",
                          ])
                      ?>
                    </div>

                </div>


                <?=
                    form::input([
                        "title" => "Alamat",
                        "type" => "text",
                        "fc" => "alamat",
                        "placeholder" => "tambahkan alamat",
                    ])
                ?>

                <div class="scroll-table mt-5 mb-3">
                    <table class="table" id="produk-list">
                        <tr class="bg-primary">
                            <th class="text-center">No</th>
                            <th class="text-center">Akun Biaya</th>
                            <th class="text-center">Deskripsi</th>
                            <th class="text-center">Pajak</th>
                            <th class="text-center">Jumlah</th>
                        </tr>
                    </table>

                </div>

                <div class="text-center mb-5">
                    <button type="button" id="tambah-barang" class="btn btn-primary"><i class="fas fa-plus"></i> Tambah Biaya</button>
                </div>


                <script>

                    $(document).on('click', '#tambah-barang', function(){

                        var sl = Array.from(document.querySelectorAll('tr[data-no]'));

                        var pl = sl.length + 1;

                        console.log(sl);

                        $.ajax({
                            url: '<?= site_url('admin/biaya/temp/')?>'+pl,
                            success:function(res){
                                $("#produk-list").append(res)
                            }
                        })
                    })

                </script>

                <div class="row">
                  <?=
                  form::input([
                    "type" => "hidden",
                    "fc" => "pajak",
                    "placeholder" => "total",
                  ])
                  ?>
                    <div class="col-sm-12">
                      <?=
                      form::input([
                        "title" => "Total",
                        "type" => "number",
                        "fc" => "total",
                        "placeholder" => "total",
                      ])
                      ?>
                    </div>
                </div>

                <?=
                    form::editor([
                        "title" => "Memo",
                        "type" => "text",
                        "fc" => "memo",
                        "placeholder" => "tambahkan memo",
                    ])
                ?>
                <?=
                    form::input([
                        "title" => "Lampiran",
                        "type" => "file",
                        "fc" => "lampiran",
                        "placeholder" => "tambahkan lampiran",
                    ])
                ?>
                        <div class="form-group">
                          <button type="submit" class="btn btn-primary">Simpan</button>
                          <a class="btn btn-default" href="<?= site_url('admin/biaya'); ?>">Back</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
      </div>
    </section>
</div>

<script type="text/javascript">

function formatRupiah(angka, prefix) {
  var number_string = angka.replace(/[^,\d]/g, "").toString(),
  split = number_string.split(","),
  sisa = split[0].length % 3,
  rupiah = split[0].substr(0, sisa),
  ribuan = split[0].substr(sisa).match(/\d{3}/gi);
  // tambahkan titik jika yang di input sudah menjadi angka ribuan
  if (ribuan) {
    separator = sisa ? "." : "";
    rupiah += separator + ribuan.join(".");
  }
  rupiah = split[1] != undefined ? rupiah + "," + split[1] : rupiah;
  return prefix == undefined ? rupiah : rupiah ? "" + rupiah : "";
}

  setInterval(()=>{

  	 var d = Array
  	 .from(
  	 		document.querySelectorAll('.jml')
  	 );

     function sum(tot, num){
         return tot + num;
     }

  	 var subt = Array.from(document.querySelectorAll(".tax")).map(function(e,i){

  			 var nominal = Number(d[i].value);
  			 var pcr = Number(e.value) / 100;
  			 return nominal;

  		})
  		.reduce(sum);

  		var c = Array.from(document.querySelectorAll(".tax")).map(function(e,i){

  			 var nominal = Number(d[i].value);
  			 var pcr = Number(e.value) / 100;

  			 return nominal * pcr;

  		})
  		.reduce(sum);

      document.getElementById('pajak').value = c;

      var tot = c + subt;

      document.getElementById('total').value = tot;
      var tots = tot+'';
      tots = tots.replace(/\./, ",");
      document.getElementById('total_nbr4').value = formatRupiah(tots);

  },10)

  document.getElementById('total_nbr4').setAttribute('readonly', 'true');
</script>
