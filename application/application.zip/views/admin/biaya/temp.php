<tr data-no="<?= $urutan ?>">
    <td><?= $urutan ?></td>
    <td>
        <?=
            form::select_db([
                "fc" => "databarangpembelian[$urutan][akun_biaya]",
                "placeholder" => "tambahkan kode",
                "db" => "akun",
                "data" => "id",
                "key" => ["nama_akun", "kode_akun"],
                "custome" => "({{kode_akun}}) - {{nama_akun}}",
                "custome-style" => " style='width: 250px;' ",
                "condition" => [
                    ['delete_set', '=', '0'],
                ]
            ])
        ?>
    </td>
    <td>
        <?=
            form::input([
                "type" => "text",
                "fc" => "databarangpembelian[$urutan][deskripsi]",
                "placeholder" => "isikan deskripsi",
            ])
        ?>
    </td>
    <td>
        <?=
            form::select_db([
                "type" => "password",
                "fc" => "databarangpembelian[$urutan][pajak]",
                "placeholder" => "tambahkan satuan",
                "db" => "pajak",
                "class" => " tax ",
                "data" => "persentase_efektif",
                "name" => "nama",
                "condition" => [
                    ['delete_set', '=', '0'],
                ]
            ])
        ?>
    </td>
    <td>
        <?=
            form::input([
                "type" => "number",
                "fc" => "databarangpembelian[$urutan][jumlah]",
                "class"=> "jml",
                "placeholder" => "harga",
            ])
        ?>
    </td>
</tr>
