<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
        <div class="col-sm-6">
            <h1 class="m-0 text-dark">Biaya</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <?php
              link_button([
                  "link" => "admin/biaya/tambah_data",
                  "class" => "btn btn-primary float-right",
                  "text" => "Tambah Data",
              ]);
          ?>
        </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <section class="content">



                  <div class="row">
                      <div class="col-md-6">
                        <div class="card card-primary card-outline">
                          <div class="card-header" style="background-color: #cef1fd;">
                            <h3 class="card-title">Total Biaya Bulan Ini</h3>

                            <div class="card-tools">
                              <button type="button" class="btn btn-tool" data-card-widget="collapse"><i style="color: #333;" class="fas fa-minus"></i>
                              </button>
                            </div>
                            <!-- /.card-tools -->
                          </div>
                          <!-- /.card-header -->
                          <div class="card-body" style="display: block;">
                            <small>total</small>
                            <p><?= $total ?></p>
                          </div>
                          <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                      </div>
                      <!-- /.col -->
                      <div class="col-md-6">
                        <div class="card card-primary card-outline">
                          <div class="card-header" style="background-color: #cef1fd;">
                            <h3 class="card-title">Biaya 30 Hari Terakhir</h3>

                            <div class="card-tools">
                              <button type="button" class="btn btn-tool" data-card-widget="collapse"><i style="color: #333;" class="fas fa-minus"></i>
                              </button>
                            </div>
                            <!-- /.card-tools -->
                          </div>
                          <!-- /.card-header -->
                          <div class="card-body">
                            <small>total</small>
                            <p>Rp. 0,00</p>
                          </div>
                          <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                      </div>
                    </div>


      <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <?php
                        link_button([
                            "link" => "admin/biaya/exls",
                            "class" => "btn btn-primary",
                            "text" => "Export Excel",
                        ]);
                    ?>
                </div>
                <div class="card-body">
                    <?= $datatable ?>
                </div>
            </div>
        </div>
      </div>
    </section>
</div>

<script type="text/javascript">


var linkUrl = '<?= site_url('') ?>admin/biaya/tambah_data';

$(document).ready(function(){
    tableku.on( 'draw', function () {

        $(".dataTables_empty").html(`

            <a href="${linkUrl}" class="btn btn-primary mt-5 mb-5"><i class="fas fa-plus"></i> Buat Transaksi Baru</a>

        `)

    })
})


</script>

<script>

$(document).ready(function(){
    tableku.on( 'draw', function () {

        function formatRupiah(angka, prefix){
			var number_string = angka.replace(/[^,\d]/g, '').toString(),
			split   		= number_string.split(','),
			sisa     		= split[0].length % 3,
			rupiah     		= split[0].substr(0, sisa),
			ribuan     		= split[0].substr(sisa).match(/\d{3}/gi);

			// tambahkan titik jika yang di input sudah menjadi angka ribuan
			if(ribuan){
				separator = sisa ? '.' : '';
				rupiah += separator + ribuan.join('.');
			}

			rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
			return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
		}

        Array.from(document.querySelectorAll('.total')).forEach(function(elm){
            if(elm.innerText == ''){
                elm.innerText = 'Rp. 0,00';
            }else{
                elm.innerText = 'Rp. '+formatRupiah(elm.innerText)+',00';
            }
        })

    });
})


</script>
