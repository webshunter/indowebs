<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
        <div class="col-sm-6">
            <h1 class="m-0 text-dark">Ubah Kontak</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="{{ url('toko') }}">Home</a></li>
            </ol>
        </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <section class="content">
      <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form action="<?= site_url('admin/kontak/update') ?>" method="post" enctype="multipart/form-data">

        <?=
            form::input([
                "type" => "hidden",
                "fc" => "id",
                "value" => $form_data->id,
            ])
        ?>

         <div class="card-body">

                    <h3><i class="fas fa-user-alt"></i> Info Kontak</h3>

                    <?=
                        form::input([
                            "title" => "Kode",
                            "type" => "text",
                            "required" => true,
                            "fc" => "kode",
                            "required" => true,
                            "placeholder" => "tambahkan kode",
                            "value" => $form_data->kode,
                        ])
                    ?>

                    <?=
                        form::input([
                            "title" => "Nama Panggilan",
                            "type" => "text",
                            "fc" => "nama_panggilan",
                            "required" => true,
                            "placeholder" => "tambahkan nama_panggilan",
                            "value" => $form_data->nama_panggilan,
                        ])
                    ?>

                    <?=
                        form::radiobutton([
                            "title" => "Tipe Kontak",
                            "type" => "password",
                            "fc" => "tipe_kontak",
                            "placeholder" => "tambahkan tipe_kontak",
                            "db" => "tipekontak",
                            "required" => true,
                            "data" => "id",
                            "name" => "pilihan",
							"condition" => [
								"delete_set" => "0"
							],
                            "selected" => $form_data->tipe_kontak,
                        ])
                    ?>

                    <div class="row">
                        <div class="col-sm-12">
                            <?=
                                form::select_db([
                                    "title" => "Group Kontak",
                                    "type" => "password",
                                    "fc" => "group_kontak",
                                    "placeholder" => "tambahkan group_kontak",
                                    "db" => "goupkontak",
                                    "data" => "id",
                                    "name" => "pilihan",
                                    "selected" => $form_data->group_kontak,
                                ])
                            ?>
                        </div>
                    </div>

                </div>

                <div class="card-body">

                    <h3><i class="fas fa-suitcase"></i> Informasi Umum</h3>






                <div class="row">
                    <div class="col-sm-4">
                         <?=
                            form::select_db([
                                "title" => "Panggilan",
                                "type" => "text",
                                "fc" => "panggilan",
                                "placeholder" => "tambahkan panggilan",
                                "db" => "panggilan",
                                "data" => "id",
                                "name" => "pilihan",
                                "selected" => $form_data->panggilan,
                            ])
                        ?>
                    </div>
                    <div class="col-sm-4">

                        <?=
                            form::input([
                                "title" => "Nama Lengkap",
                                "type" => "text",
                                "required" => true,
                                "fc" => "nama_awal",
                                "placeholder" => "tambahkan nama_awal",
                                "value" => $form_data->nama_awal,
                            ])
                        ?>
                    </div>
                    <div class="col-sm-4">
                        <?=
                            form::input([
                                "title" => "Handphone",
                                "type" => "text",
                                "required" => true,
                                "fc" => "handphone",
                                "placeholder" => "tambahkan handphone",
                                "value" => $form_data->handphone,
                            ])
                        ?>
                    </div>
                </div>

                <div class='row'>
                    <div class="col-sm-4">
                        <?=
                            form::select_db([
                                "title" => "Identitas",
                                "type" => "text",
                                "fc" => "identitas",
                                "db" => "identitas",
                                "data" => "id",
                                "name" => "pilihan",
                                "selected" => $form_data->identitas,
                            ])
                        ?>
                    </div>
                    <div class="col-sm-8">
                        <?=
                            form::input([
                                "title" => "Id Identitas",
                                "type" => "text",
                                "fc" => "id_identitas",
                                "placeholder" => "tambahkan identitas",
                                "value" => $form_data->id_identitas,
                            ])
                        ?>
                    </div>
                </div>


                <?=
                    form::input([
                        "title" => "Email",
                        "type" => "email",
                        "fc" => "email",
                        "placeholder" => "tambahkan email",
                        "value" => $form_data->email,
                    ])
                ?>

                <?=
                    form::input([
                        "title" => "Info Lain",
                        "type" => "text",
                        "fc" => "info_lain",
                        "placeholder" => "tambahkan info_lain",
                        "value" => $form_data->info_lain,
                    ])
                ?>

                <?=
                    form::input([
                        "title" => "Nama Perusahaan",
                        "type" => "text",
                        "fc" => "nama_perusahaan",
                        "placeholder" => "tambahkan nama_perusahaan",
                        "value" => $form_data->nama_perusahaan,
                    ])
                ?>

                <?=
                    form::input([
                        "title" => "Telp",
                        "type" => "text",
                        "fc" => "telp",
                        "placeholder" => "tambahkan telp",
                        "value" => $form_data->telp,
                    ])
                ?>

                <?=
                    form::input([
                        "title" => "Fax",
                        "type" => "text",
                        "fc" => "fax",
                        "placeholder" => "tambahkan fax",
                        "value" => $form_data->fax,
                    ])
                ?>

                <?=
                    form::input([
                        "title" => "NPWP",
                        "type" => "text",
                        "fc" => "npwp",
                        "placeholder" => "tambahkan npwp",
                        "value" => $form_data->npwp,
                    ])
                ?>

                <!-- <?=
                    form::input([
                        "title" => "Alamat Pembayaran",
                        "type" => "text",
                        "fc" => "alamat_pembayaran",
                        "placeholder" => "tambahkan alamat_pembayaran",
                        "value" => $form_data->alamat_pembayaran,
                    ])
                ?> -->

                <?=
                    form::input([
                        "title" => "Alamat Pengirim",
                        "type" => "text",
                        "fc" => "alamat_pengirim",
                        "placeholder" => "tambahkan alamat_pengirim",
                        "value" => $form_data->alamat_pengirim,
                    ])
                ?>

                </div>

                <div class="card-body">
                    <h3><i class="fa fa-money-check-alt"></i> Daftar Bank</h3>
                    <div class="card" id="bank">


                        <?php
                            foreach(binaryToArray($form_data->bank) as $key => $val) :
                        ?>

                        <div class="card-body flash-bank"  data-no="<?= $key + 1 ?>">
                            <?php $urutan = $key + 1; ?>
                            <?=
                                form::input([
                                    "title" => "Nama Bank",
                                    "type" => "text",
                                    "fc" => "bank[$urutan][nama_bank]",
                                    "placeholder" => "tambahkan bank",
                                    "value" => $val['nama_bank'],
                                ])
                            ?>

                            <?=
                                form::input([
                                    "title" => "Kantor Cabang Bank",
                                    "type" => "text",
                                    "fc" => "bank[$urutan][kantor_cabang_bank]",
                                    "placeholder" => "tambahkan bank",
                                    "value" => $val['kantor_cabang_bank'],
                                ])
                            ?>

                            <?=
                                form::input([
                                    "title" => "Pemegang Akun Bank",
                                    "type" => "text",
                                    "fc" => "bank[$urutan][pemegang_akun_bank]",
                                    "placeholder" => "tambahkan bank",
                                    "value" => $val['pemegang_akun_bank'],
                                ])
                            ?>

                            <?=
                                form::input([
                                    "title" => "Nomor Rekening",
                                    "type" => "text",
                                    "fc" => "bank[$urutan][nomor_rekening]",
                                    "placeholder" => "tambahkan bank",
                                    "value" => $val['nomor_rekening'],
                                ])
                            ?>
                        </div>

                                    <?php endforeach; ?>

                    </div>
                    <div class="text-center">
                        <button type="button" id="tambah-barang" class="btn btn-primary"><i class="fas fa-plus"></i> Tambah Bank</button>
                    </div>
                </div>


                <script>
                    $(document).on('click', '#tambah-barang', function(){
                        var sl = Array.from(document.querySelectorAll('tr[data-no]'));
                        var pl = sl.length + 1;
                        console.log(sl);
                        $.ajax({
                            url: '<?= site_url('admin/kontak/temp/')?>'+pl,
                            success:function(res){
                                $("#bank").append(res)
                            }
                        })
                    })

                </script>

                <div class="card-body">

                    <h3><i class="fas fa-file-invoice"></i> Info Kontak</h3>


                <?=
                    form::select_db([
                        "title" => "Akun Piutang",
                        "type" => "password",
                        "fc" => "akun_piutang",
                        "placeholder" => "tambahkan akun_piutang",
                        "db" => "akun",
                        "data" => "id",
                        "name" => "nama_akun",
                        "selected" => $form_data->akun_piutang,
                    ])
                ?>

                <?=
                    form::select_db([
                        "title" => "Akun Hutang",
                        "type" => "password",
                        "fc" => "akun_hutang",
                        "placeholder" => "tambahkan akun_hutang",
                        "db" => "akun",
                        "data" => "id",
                        "name" => "nama_akun",
                        "selected" => $form_data->akun_hutang,
                    ])
                ?>

                <?=
                    form::input([
                        "title" => "Syarat Pembayaran Utama",
                        "type" => "text",
                        "fc" => "syarat_pembayaran_utama",
                        "placeholder" => "tambahkan syarat_pembayaran_utama",
                        "value" => $form_data->syarat_pembayaran_utama,
                    ])
                ?>

                </div>

                        <div class="form-group">
                          <button type="submit" class="btn btn-primary">Simpan</button>
                          <a class="btn btn-default" href="<?= site_url('admin/kontak'); ?>">Back</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
      </div>
    </section>
</div>
