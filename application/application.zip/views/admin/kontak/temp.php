<div class="card-body flash-bank"  data-no="<?= $urutan ?>">
                            <?=
                                form::input([
                                    "title" => "Nama Bank",
                                    "type" => "text",
                                    "fc" => "bank[$urutan][nama_bank]",
                                    "placeholder" => "tambahkan bank",
                                ])
                            ?>
                            
                            <?=
                                form::input([
                                    "title" => "Kantor Cabang Bank",
                                    "type" => "text",
                                    "fc" => "bank[$urutan][kantor_cabang_bank]",
                                    "placeholder" => "tambahkan bank",
                                ])
                            ?>
                            
                            <?=
                                form::input([
                                    "title" => "Pemegang Akun Bank",
                                    "type" => "text",
                                    "fc" => "bank[$urutan][pemegang_akun_bank]",
                                    "placeholder" => "tambahkan bank",
                                ])
                            ?>
                            
                            <?=
                                form::input([
                                    "title" => "Nomor Rekening",
                                    "type" => "text",
                                    "fc" => "bank[$urutan][nomor_rekening]",
                                    "placeholder" => "tambahkan bank",
                                ])
                            ?>
                        </div>