<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
        <div class="col-sm-6">
            <h1 class="m-0 text-dark">Kontak</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
            <?php
                link_button([
                    "link" => "admin/kontak/tambah_data",
                    "class" => "btn btn-primary float-right btn-export",
                    "text" => "Tambah Data",
                ]);
            ?>
        </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <section class="content">
      <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <ul class="nav justify-content-center">
                        <?php foreach($this->db->query("SELECT * FROM tipekontak WHERE delete_set = '0'")->result() as $kk => $vl) : ?>
                            <li class="nav-item">
                                <a class="nav-link edp" data-c="<?= $vl->id; ?>" onclick="openTable(<?= $vl->id; ?>); return false;" href="#"><?= $vl->pilihan; ?></a>
                            </li>
                        <?php endforeach ?>
                    </ul>
                </div>
                <div class="card-header">
                    <?php
                        link_button([
                            "id" => "exportexcls",
                            "link" => "admin/kontak/exls",
                            "class" => "btn btn-primary",
                            "text" => "Export Excel",
                        ]);
                    ?>
                </div>
                <div class="card-body">
                    <?= $datatable ?>
                </div>
            </div>
        </div>
      </div>
    </section>
</div>

<script>

var sLink = '<?= site_url() ?>admin/kontak/exls';

function openTable(a){
    sessionStorage.setItem('s', a);
    location.reload();
}

if(sessionStorage.getItem('s') == undefined){
  sessionStorage.setItem('s', '1');
}


if(sessionStorage.getItem('s') != undefined){
    globalThis.tableUrl = globalThis.tableUrlStart+'/'+sessionStorage.getItem('s');
    $(document).ready(function(){
        Array.from(document.querySelectorAll('.edp')).forEach(function(el, i){
            if(el.getAttribute('data-c') == sessionStorage.getItem('s')){
                var s = document.getElementById('exportexcls');
                s.setAttribute('href', sLink+'/'+el.getAttribute('data-c'));
                el.setAttribute('class', 'nav-link edp active ');
            }else{
                el.setAttribute('class', 'nav-link edp');
            }

        })

    })
}


$(document).ready(function(){
    tableku.on( 'draw', function () {

        function formatRupiah(angka, prefix){
			var number_string = angka.replace(/[^,\d]/g, '').toString(),
			split   		= number_string.split(','),
			sisa     		= split[0].length % 3,
			rupiah     		= split[0].substr(0, sisa),
			ribuan     		= split[0].substr(sisa).match(/\d{3}/gi);

			// tambahkan titik jika yang di input sudah menjadi angka ribuan
			if(ribuan){
				separator = sisa ? '.' : '';
				rupiah += separator + ribuan.join('.');
			}

			rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
			return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
		}

        Array.from(document.querySelectorAll('.bts')).forEach(function(elm){
            if(elm.innerText == ''){
                elm.innerText = '-';
            }else{
                elm.innerText = formatRupiah(elm.innerText);
            }
        })

        Array.from(document.querySelectorAll('.saldo')).forEach(function(elm){
            if(elm.innerText == ''){
                elm.innerText = 'Rp. 0,00';
            }else{
                elm.innerText = 'Rp. '+formatRupiah(elm.innerText)+',00';
            }
        })

    });
})

</script>
