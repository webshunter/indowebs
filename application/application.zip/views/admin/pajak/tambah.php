<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
        <div class="col-sm-6">
            <h1 class="m-0 text-dark">Tambahkan Pajak</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="{{ url('toko') }}">Home</a></li>
            </ol>
        </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <section class="content">
      <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form action="<?= site_url('admin/pajak/simpan') ?>" method="post" enctype="multipart/form-data">

                <?=
                    form::select_db([
                        "title" => "Pajak",
                        "type" => "password",
                        "fc" => "pajak",
                        "placeholder" => "tambahkan pajak",
                        "db" => "pilihanpajak",
                        "data" => "id",
                        "name" => "pilihan",
                    ])
                ?>

                <?=
                    form::input([
                        "title" => "Nama",
                        "type" => "text",
                        "fc" => "nama",
                        "placeholder" => "tambahkan nama",
                    ])
                ?>

                <?=
                    form::input([
                        "title" => "Persentase Efektif",
                        "type" => "number",
                        "fc" => "persentase_efektif",
                        "placeholder" => "tambahkan persentase_efektif",
                    ])
                ?>

                <?=
                    form::input([
                        "title" => "Pemotongan",
                        "type" => "checkbox",
                        "fc" => "pemotongan",
                        "placeholder" => "tambahkan pemotongan",
                        "value" => "1",
                    ])
                ?>

                <?=
                    form::select_db([
                        "title" => "Akun Pajak Penjualan",
                        "type" => "password",
                        "fc" => "akun_pajak_penjualan",
                        "placeholder" => "tambahkan akun_pajak_penjualan",
                        "db" => "akun",
                        "data" => "id",
                        "key" => ["nama_akun", "kode_akun"],
                        "custome" => "({{kode_akun}}) - {{nama_akun}}",
                    ])
                ?>

                <?=
                    form::select_db([
                        "title" => "Akun Pajak Pembelian",
                        "type" => "password",
                        "fc" => "akun_pajak_pembelian",
                        "placeholder" => "tambahkan akun_pajak_pembelian",
                        "db" => "akun",
                        "data" => "id",
                        "key" => ["nama_akun", "kode_akun"],
                        "custome" => "({{kode_akun}}) - {{nama_akun}}",
                    ])
                ?>

                        <div class="form-group">
                          <button type="submit" class="btn btn-primary">Simpan</button>
                          <a class="btn btn-default" href="<?= site_url('admin/pajak'); ?>">Back</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
      </div>
    </section>
</div>
