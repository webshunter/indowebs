<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
        <div class="col-sm-6">
            <h1 class="m-0 text-dark">Ubah Penjualan</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
            </ol>
        </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <section class="content">
      <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form action="<?= site_url('admin/penjualan/update') ?>" method="post" enctype="multipart/form-data">

        <?=
            form::input([
                "type" => "hidden",
                "fc" => "id",
                "value" => $form_data->id,
            ])
        ?>
    <div class="row">
                    <div class="col-sm-6">

                        <?=
                            form::input([
                                "title" => "No Nota",
                                "type" => "text",
                                "fc" => "no_nota",
                                "readonly" => true,
                                "required" => true,
                                "placeholder" => "tambahkan no_nota",
                                "value" => $form_data->no_nota
                            ])
                        ?>

                        <?=
                            form::input([
                                "title" => "No Faktur",
                                "type" => "text",
                                "fc" => "no_faktur",
                                "required" => true,
                                "placeholder" => "tambahkan no faktur",
                                "value" => $form_data->no_faktur
                            ])
                        ?>

                        <?=
                            form::input([
                                "title" => "Tanggal",
                                "type" => "date",
                                "fc" => "tanggal",
                                "placeholder" => "tambahkan tanggal",
                                "value" => $form_data->tanggal
                            ])
                        ?>

                        <?=
                            form::select_db([
                                "title" => "Termin",
                                "type" => "password",
                                "fc" => "termin",
                                "placeholder" => "tambahkan termin",
                                "db" => "termin",
                                "data" => "pilihan",
                                "name" => "pilihan",
                                "selected" => $form_data->termin
                            ])
                        ?>

                        <?=
                            form::input([
                                "title" => "Jatuh Tempo",
                                "type" => "date",
                                "readonly" => true,
                                "fc" => "jatuh_tempo",
                                "placeholder" => "tambahkan jatuh_tempo",
                                "value" => $form_data->jatuh_tempo
                            ])
                        ?>


                        <script type="text/javascript">
                            $(document).on('change', '#termin', function(){
                              console.log(document.getElementById('tanggal').value);
                              var self = this;
                              if (document.getElementById('tanggal').value == "") {
                                setTimeout(function(){
                                  document.getElementById('tanggal').focus();
                                  $('#termin').val('');
                                  $('#termin').select2().trigger('change');
                                },0)
                              }else{
                                function format(a) {
                                  var str = ""+a;
                                  var pad = "00";
                                  var ans = pad.substring(0, pad.length - str.length) + str;
                                  return ans;
                                }
                                var oneDay = 86400000;
                                var rentang = Number(this.value) * oneDay;
                                var tanggal = new Date(document.getElementById('tanggal').value).getTime() + rentang;
                                tanggal = new Date(tanggal);
                                var s = tanggal.getFullYear() + '-'+format(tanggal.getMonth() + 1) +'-'+format(tanggal.getDate());
                                document.getElementById('jatuh_tempo').value = s;
                              }
                            })


                        </script>

                        <?=
                            form::input([
                                "title" => "Tag",
                                "type" => "text",
                                "fc" => "tag",
                                "tag" => true,
                                "placeholder" => "tambahkan tag",
                                "value" => $form_data->tag
                            ])
                        ?>

                    </div>
                    <div class="col-sm-6">
                        <?=
                            form::select_db([
                                "title" => "Kode Pelanggan",
                                "type" => "password",
                                "fc" => "kode",
                                "placeholder" => "tambahkan kode",
                                "db" => "kontak",
                                "data" => "id",
                                "name" => "kode",
                                "condition" => [
                                    ['tipe_kontak', 'LIKE', '%:\"1\"%'],
                                    ['delete_set', '=', '0'],
                                ],
                                "selected" => $form_data->kode
                            ])
                        ?>

                        <?=
                            form::input([
                                "title" => "Nama",
                                "type" => "text",
                                "fc" => "nama",
                                "placeholder" => "tambahkan nama",
                                "value" => $form_data->nama
                            ])
                        ?>

                        <?=
                            form::input([
                                "title" => "Alamat",
                                "type" => "text",
                                "fc" => "alamat",
                                "placeholder" => "tambahkan alamat",
                                "value" => $form_data->alamat
                            ])
                        ?>

                        <?=
                            form::input([
                                "title" => "Email",
                                "type" => "email",
                                "fc" => "email",
                                "placeholder" => "tambahkan email",
                                "value" => $form_data->email
                            ])
                        ?>

                        <div class="row">
                            <div class="col-sm-6">
                              <?=
                              form::input([
                                "title" => "Disc 1 (%)",
                                "type" => "number",
                                "fc" => "disc1",
                                "max" => "100",
                                "placeholder" => "0 - 10",
                                "value" => $form_data->disc1
                              ])
                              ?>
                            </div>
                            <div class="col-sm-6">
                              <?=
                              form::input([
                                "title" => "Disc 2 (%)",
                                "type" => "number",
                                "fc" => "disc2",
                                "max" => "100",
                                "placeholder" => "0 - 100",
                                "value" => $form_data->disc2
                              ])
                              ?>
                            </div>
                        </div>

                        <?=
                            form::select_db([
                                "title" => "Gudang",
                                "type" => "text",
                                "fc" => "gudang",
                                "db" => "gudang",
                                "data" => "id",
                                "key" => ["kode", "nama"],
                                "custome" => "({{kode}}) - {{nama}}",
                                "selected" => $form_data->gudang
                            ])
                        ?>

                        <script>
                            $('#kode').on('select2:select', function (e) {
                                var data = e.params.data;
                                console.log(data.element.value);
                                $.ajax({
                                    url: '<?= site_url('admin/kontak/api/') ?>'+ data.element.value,
                                    success:function(res){
                                        res = JSON.parse(res);
                                        document.getElementById('nama').value = res.nama_panggilan;
                                        document.getElementById('alamat').value = res.alamat_pengirim;
                                    }
                                })
                            });

                        </script>
                    </div>
                </div>

                <!--  -->
                <div class="scroll-table mt-5 mb-3">
                    <table class="table" id="produk-list">
                        <tr class="bg-primary">
                            <th class="text-center">No</th>
                            <th class="text-center">Nama Barang</th>
                            <th class="text-center">Qty</th>
                            <th class="text-center">Satuan</th>
                            <th class="text-center">Harga</th>
                            <th class="text-center">Diskon <br> ( % )</th>
                            <th class="text-center">Diskon <br> ( Rp )</th>
                            <th class="text-center">Jumlah</th>
                        </tr>
    <!-- start table -->

                            <?php

                              $xx =  $this->db->query("SELECT * FROM datapenjualan WHERE pembelian_id = '$form_data->id' ")->result();


                              foreach($xx as $kk => $eva) :

                                $urutan = $kk + 1;

                            ?>

                        <tr data-no="<?= $urutan ?>">
    <td><?= $urutan ?></td>
    <td>
        <?=
            form::select_db([
                "type" => "password",
                "fc" => "databarangpembelian[$urutan][produk]",
                "placeholder" => "tambahkan kode",
                "db" => "produk",
                "data" => "id",
                "name" => "nama",
                "custome-style" => " style='width: 250px;' ",
                "condition" => [
                    ['delete_set', '=', '0'],
                ],
                "selected" => $eva->produk
            ])
        ?>
    </td>
    <td>
        <?=
            form::input([
                "type" => "number",
                "fc" => "databarangpembelian[$urutan][qty]",
                "custome-style" => " style='width: 80px;' ",
                "placeholder" => "qty",
                "value" => $eva->qty
            ])
        ?>
    </td>
    <td>
        <?=
            form::select_db([
                "type" => "password",
                "fc" => "databarangpembelian[$urutan][satuan]",
                "placeholder" => "tambahkan satuan",
                "db" => "satuan",
                "data" => "id",
                "name" => "satuan",
                "readonly" => true,
                "custome-style" => " style='width: 120px;' ",
                "condition" => [
                    ['delete_set', '=', '0'],
                ],
                "selected" => $eva->satuan
            ])
        ?>
    </td>
    <td>
        <?=
            form::input([
                "type" => "number",
                "fc" => "databarangpembelian[$urutan][harga]",
                "custome-style" => " style='width: 150px;' ",
                "placeholder" => "harga",
                "value" => $eva->harga
            ])
        ?>
    </td>
    <td>
        <?=
            form::input([
                "type" => "number",
                "fc" => "databarangpembelian[$urutan][diskon]",
                "custome-style" => " style='width: 80px;' ",
                "placeholder" => "0 - 100",
                "max" => "100",
                "value" => $eva->diskon
            ])
        ?>
    </td>
    <td>
        <?=
            form::input([
                "type" => "number",
                "fc" => "databarangpembelian[$urutan][diskon_nominal]",
                "custome-style" => " style='width: 120px;' ",
                "placeholder" => " - ",
                "value" => $eva->diskon_nominal
            ])
        ?>
    </td>
    <td>
        <?=
            form::input([
                "type" => "number",
                "fc" => "databarangpembelian[$urutan][jumlah]",
                "class" => "pembayaran-item",
                "readonly" => true,
                "custome-style" => " style='width: 150px;' ",
                "placeholder" => " - ",
                "value" => $eva->jumlah
            ])
        ?>
    </td>
</tr>




    <script>

        $(document).ready(function(){
            var sp<?= $urutan ?> = "<?= str_replace("]", "b", str_replace("[", "a", "databarangpembelian[$urutan][produk]")); ?>";
            var sv<?= $urutan ?> = "<?= str_replace("]", "b", str_replace("[", "a", "databarangpembelian[$urutan][satuan]")); ?>";
            var qty<?= $urutan ?> = "<?= str_replace("]", "b", str_replace("[", "a", "databarangpembelian[$urutan][qty]")); ?>";
            var harga<?= $urutan ?> = "<?= str_replace("]", "b", str_replace("[", "a", "databarangpembelian[$urutan][harga]")); ?>";
            var diskon<?= $urutan ?> = "<?= str_replace("]", "b", str_replace("[", "a", "databarangpembelian[$urutan][diskon]")); ?>";
            var diskon_nominal<?= $urutan ?> = "<?= str_replace("]", "b", str_replace("[", "a", "databarangpembelian[$urutan][diskon_nominal]")); ?>";
            var jumlah<?= $urutan ?> = "<?= str_replace("]", "b", str_replace("[", "a", "databarangpembelian[$urutan][jumlah]")); ?>";
            var unit = sv<?= $urutan ?>;

            var qty = document.getElementById(qty<?= $urutan ?>);
            var diskon = document.getElementById(diskon<?= $urutan ?>);
            var diskon_nominal = document.getElementById(diskon_nominal<?= $urutan ?>);
            var jumlah = document.getElementById(jumlah<?= $urutan ?>);
            var harga = document.getElementById(harga<?= $urutan ?>);

            diskon_nominal.addEventListener('keyup', function(){
                var qty = document.getElementById(qty<?= $urutan ?>);
                var diskon = document.getElementById(diskon<?= $urutan ?>);
                var diskon_nominal = document.getElementById(diskon_nominal<?= $urutan ?>);
                var harga = document.getElementById(harga<?= $urutan ?>);
                var jumlah = document.getElementById(jumlah<?= $urutan ?>);
                var qty = Number(qty.value);
                var harga = Number(harga.value);
                var diskon = Number(diskon.value);
                var diskon_nominal = Number(diskon_nominal.value);
                var hargaawal = qty * harga;
                var gargaMinDis1 = hargaawal - ( hargaawal * diskon / 100 );
                var hargaakhir = gargaMinDis1 - diskon_nominal;
                jumlah.value = hargaakhir;
            }, true)

            qty.addEventListener('keyup', function(){
                var qty = document.getElementById(qty<?= $urutan ?>);
                var diskon = document.getElementById(diskon<?= $urutan ?>);
                var diskon_nominal = document.getElementById(diskon_nominal<?= $urutan ?>);
                var harga = document.getElementById(harga<?= $urutan ?>);
                var jumlah = document.getElementById(jumlah<?= $urutan ?>);
                var qty = Number(qty.value);
                var harga = Number(harga.value);
                var diskon = Number(diskon.value);
                var diskon_nominal = Number(diskon_nominal.value);
                var hargaawal = qty * harga;
                var gargaMinDis1 = hargaawal - ( hargaawal * diskon / 100 );
                var hargaakhir = gargaMinDis1 - diskon_nominal;
                jumlah.value = hargaakhir;
            }, true)

            diskon.addEventListener('keyup', function(){
                var qty = document.getElementById(qty<?= $urutan ?>);
                var diskon = document.getElementById(diskon<?= $urutan ?>);
                var diskon_nominal = document.getElementById(diskon_nominal<?= $urutan ?>);
                var harga = document.getElementById(harga<?= $urutan ?>);
                var jumlah = document.getElementById(jumlah<?= $urutan ?>);
                var qty = Number(qty.value);
                var harga = Number(harga.value);
                var diskon = Number(diskon.value);
                var diskon_nominal = Number(diskon_nominal.value);
                var hargaawal = qty * harga;
                var gargaMinDis1 = hargaawal - ( hargaawal * diskon / 100 );
                var hargaakhir = gargaMinDis1 - diskon_nominal;
                jumlah.value = hargaakhir;
            }, true)

            harga.addEventListener('keyup', function(){
                var qty = document.getElementById(qty<?= $urutan ?>);
                var diskon = document.getElementById(diskon<?= $urutan ?>);
                var diskon_nominal = document.getElementById(diskon_nominal<?= $urutan ?>);
                var harga = document.getElementById(harga<?= $urutan ?>);
                var jumlah = document.getElementById(jumlah<?= $urutan ?>);
                var qty = Number(qty.value);
                var harga = Number(harga.value);
                var diskon = Number(diskon.value);
                var diskon_nominal = Number(diskon_nominal.value);
                var hargaawal = qty * harga;
                var gargaMinDis1 = hargaawal - ( hargaawal * diskon / 100 );
                var hargaakhir = gargaMinDis1 - diskon_nominal;
                jumlah.value = hargaakhir;
            }, true)

            $('#'+sp<?= $urutan ?>).on('select2:select', function (e) {
                var data = e.params.data;
                $.ajax({
                    url: '<?= site_url('admin/produk/api/') ?>'+ data.element.value,
                    success:function(res){
                        res = JSON.parse(res);
                        res = res.unit;
                        $('#'+unit).val(res);
                        $('#'+unit).select2().trigger('change');
                    }
                })
            });






        })

    </script>


<?php endforeach; ?>

    <!-- end table -->


                    </table>

                </div>

                <div class="text-center mb-5">
                    <button type="button" id="tambah-barang" class="btn btn-primary"><i class="fas fa-plus"></i> Tambah Barang</button>
                </div>

                <div class="row">
                    <div class="col-sm-6">
                        <?=
                            form::input([
                                "title" => "Subtotal",
                                "type" => "number",
                                "fc" => "subtotal",
                                "readonly" => true,
                                "placeholder" => "subtotal",
                                "value" => $form_data->subtotal
                            ])
                        ?>
                    </div>
                    <div class="col-sm-6">
                        <?=
                            form::input([
                                "title" => "Diskon Faktur",
                                "type" => "number",
                                "fc" => "diskon_faktur",
                                "placeholder" => "0",
                                "value" => $form_data->diskon_faktur
                            ])
                        ?>

                    </div>
                    <div class="col-sm-6">
                        <?=
                            form::input([
                                "title" => "Ongkir",
                                "type" => "number",
                                "fc" => "ongkir",
                                "placeholder" => "tambahkan ongkir",
                                "value" => $form_data->ongkir
                            ])
                        ?>
                    </div>
                    <div class="col-sm-12">
                        <?=
                            form::input([
                                "title" => "Total ( DPP )",
                                "type" => "number",
                                "fc" => "total",
                                "readonly" => true,
                                "placeholder" => "Total Pembayaran",
                                "value" => $form_data->total
                            ])
                        ?>
                    </div>
                    <div class="col-sm-6">
                      <?=
                          form::select_db([
                              "title" => "Pajak",
                              "type" => "number",
                              "fc" => "pajak",
                              "db" => "pajak",
                              "data" => "persentase_efektif",
                              "name" => "nama",
                              "condition" => [
                                  ['delete_set', '=', '0'],
                              ],
                              "selected" => $form_data->pajak
                          ])
                      ?>
                    </div>
                    <div class="col-sm-12">
                        <?=
                            form::input([
                                "title" => "Grand Total",
                                "type" => "number",
                                "fc" => "grand_total",
                                "readonly" => true,
                                "placeholder" => "Total Pembayaran",
                                "selected" => $form_data->grand_total
                            ])
                        ?>
                    </div>
                </div>

                <script>


                    $(document).on('click', '#tambah-barang', function(){

                        var sl = Array.from(document.querySelectorAll('tr[data-no]'));

                        var pl = sl.length + 1;

                        console.log(sl);

                        $.ajax({
                            url: '<?= site_url('admin/pembelian/temp/')?>'+pl,
                            success:function(res){
                                $("#produk-list").append(res)
                            }
                        })
                    })

                </script>

                <div class="row">
                    <div class="col-sm-6">
                        <?=
                            form::input([
                                "title" => "Pembayaran Tunai",
                                "type" => "number",
                                "fc" => "pembayaran",
                                "placeholder" => "tambahkan pembayaran",
                                "value" => $form_data->pembayaran
                            ])
                        ?>
                    </div>
                    <div class="col-sm-6">
                        <?=
                            form::input([
                                "title" => "Sisa Hutang",
                                "type" => "number",
                                "fc" => "hutang",
                                "readonly" => true,
                                "placeholder" => "tambahkan pembayaran",
                                "value" => $form_data->hutang
                            ])
                        ?>
                    </div>
                </div>
                        <div class="form-group mt-3">
                          <button type="submit" class="btn btn-primary">Simpan</button>
                          <a class="btn btn-default" href="<?= site_url('admin/pembelian'); ?>">Kembali</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
      </div>
    </section>
</div>
<script>


    var ongkir = null;

    var pajak = null;

    var pembayaran = null;

    function formatRupiah(angka, prefix) {
      var number_string = angka.replace(/[^,\d]/g, "").toString(),
      split = number_string.split(","),
      sisa = split[0].length % 3,
      rupiah = split[0].substr(0, sisa),
      ribuan = split[0].substr(sisa).match(/\d{3}/gi);
      // tambahkan titik jika yang di input sudah menjadi angka ribuan
      if (ribuan) {
        separator = sisa ? "." : "";
        rupiah += separator + ribuan.join(".");
      }
      rupiah = split[1] != undefined ? rupiah + "," + split[1] : rupiah;
      return prefix == undefined ? rupiah : rupiah ? "" + rupiah : "";
    }


    $('#pajak').on
    ('select2:select', function (e) {
        var data = e.params.data;
        console.log(data.element.value);
        pajak = Number(data.element.value);
    });

    setInterval(function(){
      pajak = Number(document.getElementById('pajak').value);
      ongkir = Number(document.getElementById('ongkir').value);
      pembayaran = Number(document.getElementById('pembayaran').value);
    },100)

    setInterval(() => {
        var s = Array.from(document.querySelectorAll('.pembayaran-item'))
        if(s.length == 0){
            document.getElementById('hutang').value = 0;
        }else{
            var lop = s.map(function(pr){
                return Number(pr.value);
            }).reduce(sum);
            function sum(tot, num){
                return tot + num;
            }

            document.getElementById('subtotal').value = lop;

            var subtot = lop + '';
            subtot = subtot.replace(/\./g, ",")

            document.getElementById('subtotal_nbr4').value = formatRupiah(subtot);

            // cek disc1

            var disc1 = Number(document.getElementById('disc1').value);

            disc1 = lop * (disc1 / 100);

            // cek disc2
            var disc2 = Number(document.getElementById('disc2').value);

            disc2 = (lop - disc1) * (disc2 / 100);

            var cc = disc1 + disc2;

            document.getElementById('diskon_faktur').value = (disc1 + disc2);

            var disfa = (disc1 + disc2) + '';
            disfa = disfa.replace(/\./g, ",");
            document.getElementById('diskon_faktur_nbr4').value = formatRupiah(disfa);

            lop = lop - (disc1 + disc2);

            if (ongkir != null && ongkir != '' && ongkir != undefined) {
                lop = lop + ongkir;
            }

            document.getElementById('total').value = lop;

            var tott = lop + '';
            tott =  tott.replace(/\./g, ',');

            document.getElementById('total_nbr4').value = formatRupiah(tott);

            if(pajak != null && pajak != ''){
                lop = lop + ( lop * pajak / 100);
            }

            document.getElementById('grand_total').value = lop;
            var grandtot = lop + '';
            grandtot = grandtot.replace(/\./g, ',');
            document.getElementById('grand_total_nbr4').value = formatRupiah(grandtot);

            if (pembayaran != null && pembayaran != '' && pembayaran != undefined) {
                lop = lop - pembayaran;
            }
            document.getElementById('hutang').value = lop;
            var hut = lop + '';
            var hut = hut.replace(/\./g, ',');
            document.getElementById('hutang_nbr4').value = formatRupiah(hut);
        }
    }, 100);


</script>
