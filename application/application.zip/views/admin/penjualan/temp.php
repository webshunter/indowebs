<tr data-no="<?= $urutan ?>">
    <td><?= $urutan ?></td>
    <td>
        <?=
            form::select_db([
                "type" => "password",
                "fc" => "databarangpembelian[$urutan][produk]",
                "placeholder" => "tambahkan kode",
                "db" => "produk",
                "data" => "id",
                "name" => "nama",
                "custome-style" => " style='width: 250px;' ",
                "condition" => [
                    ['delete_set', '=', '0'],
                ]
            ])
        ?>
    </td>
    <td>
        <?=
            form::input([
                "type" => "number",
                "fc" => "databarangpembelian[$urutan][qty]",
                "custome-style" => " style='width: 80px;' ",
                "placeholder" => "qty",
            ])
        ?>
    </td>
    <td>
        <?=
            form::select_db([
                "type" => "password",
                "fc" => "databarangpembelian[$urutan][satuan]",
                "placeholder" => "tambahkan satuan",
                "db" => "satuan",
                "data" => "id",
                "name" => "satuan",
                "readonly" => true,
                "custome-style" => " style='width: 120px;' ",
                "condition" => [
                    ['delete_set', '=', '0'],
                ]
            ])
        ?>
    </td>
    <td>
        <?=
            form::input([
                "type" => "number",
                "fc" => "databarangpembelian[$urutan][harga]",
                "custome-style" => " style='width: 150px;' ",
                "placeholder" => "harga",
            ])
        ?>
    </td>
    <td>
        <?=
            form::input([
                "type" => "number",
                "fc" => "databarangpembelian[$urutan][diskon]",
                "custome-style" => " style='width: 80px;' ",
                "max" => "100",
                "placeholder" => "0 - 100",
            ])
        ?>
    </td>
    <td>
        <?=
            form::input([
                "type" => "number",
                "fc" => "databarangpembelian[$urutan][diskon_nominal]",
                "custome-style" => " style='width: 120px;' ",
                "placeholder" => " - ",
            ])
        ?>
    </td>
    <td>
        <?=
            form::input([
                "type" => "number",
                "fc" => "databarangpembelian[$urutan][jumlah]",
                "class" => "pembayaran-item",
                "readonly" => true,
                "custome-style" => " style='width: 150px;' ",
                "placeholder" => " - ",
            ])
        ?>
    </td>
</tr>


<script>

    $(document).ready(function(){
        var sp<?= $urutan ?> = "<?= str_replace("]", "b", str_replace("[", "a", "databarangpembelian[$urutan][produk]")); ?>";
        var sv<?= $urutan ?> = "<?= str_replace("]", "b", str_replace("[", "a", "databarangpembelian[$urutan][satuan]")); ?>";
        var qty<?= $urutan ?> = "<?= str_replace("]", "b", str_replace("[", "a", "databarangpembelian[$urutan][qty]")); ?>";
        var harga<?= $urutan ?> = "<?= str_replace("]", "b", str_replace("[", "a", "databarangpembelian[$urutan][harga]")); ?>";
        var diskon<?= $urutan ?> = "<?= str_replace("]", "b", str_replace("[", "a", "databarangpembelian[$urutan][diskon]")); ?>";
        var diskon_nominal<?= $urutan ?> = "<?= str_replace("]", "b", str_replace("[", "a", "databarangpembelian[$urutan][diskon_nominal]")); ?>";
        var jumlah<?= $urutan ?> = "<?= str_replace("]", "b", str_replace("[", "a", "databarangpembelian[$urutan][jumlah]")); ?>";
        var jumlahb<?= $urutan ?> = "<?= str_replace("]", "b", str_replace("[", "a", "databarangpembelian[$urutan][jumlah]")); ?>_nbr4";
        var unit = sv<?= $urutan ?>;

        var qty = document.getElementById(qty<?= $urutan ?>);
        var diskon = document.getElementById(diskon<?= $urutan ?>);
        var diskon_nominal = document.getElementById(diskon_nominal<?= $urutan ?>);
        var jumlah = document.getElementById(jumlah<?= $urutan ?>);
        var harga = document.getElementById(harga<?= $urutan ?>);

        setInterval(function(){

          function formatRupiah(angka, prefix) {
            var number_string = angka.replace(/[^,\d]/g, "").toString(),
            split = number_string.split(","),
            sisa = split[0].length % 3,
            rupiah = split[0].substr(0, sisa),
            ribuan = split[0].substr(sisa).match(/\d{3}/gi);
            // tambahkan titik jika yang di input sudah menjadi angka ribuan
            if (ribuan) {
              separator = sisa ? "." : "";
              rupiah += separator + ribuan.join(".");
            }
            rupiah = split[1] != undefined ? rupiah + "," + split[1] : rupiah;
            return prefix == undefined ? rupiah : rupiah ? "" + rupiah : "";
          }


            var qty = document.getElementById(qty<?= $urutan ?>);
            var diskon = document.getElementById(diskon<?= $urutan ?>);
            var diskon_nominal = document.getElementById(diskon_nominal<?= $urutan ?>);
            var harga = document.getElementById(harga<?= $urutan ?>);
            var jumlah = document.getElementById(jumlah<?= $urutan ?>);
            var jumlahb = document.getElementById(jumlahb<?= $urutan ?>);
            var qty = Number(qty.value);
            var harga = Number(harga.value);
            var diskon = Number(diskon.value);
            var diskon_nominal = Number(diskon_nominal.value);
            var hargaawal = qty * harga;
            var gargaMinDis1 = hargaawal - ( hargaawal * diskon / 100 );
            var hargaakhir = gargaMinDis1 - diskon_nominal;
            jumlah.value = hargaakhir;
            jumlahb.value = formatRupiah(hargaakhir.toString());

          },100)

        $('#'+sp<?= $urutan ?>).on('select2:select', function (e) {
            var data = e.params.data;
            $.ajax({
                url: '<?= site_url('admin/produk/api/') ?>'+ data.element.value,
                success:function(res){
                    res = JSON.parse(res);
                    res = res.unit;
                    $('#'+unit).val(res);
                    $('#'+unit).select2().trigger('change');
                }
            })
        });


    })

</script>
