<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
        <div class="col-sm-6">
            <h1 class="m-0 text-dark">Ubah Produk</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="{{ url('toko') }}">Home</a></li>
            </ol>
        </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <section class="content">
      <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form action="<?= site_url('admin/produk/update') ?>" method="post" enctype="multipart/form-data">
                        
        <?=
            form::input([
                "type" => "hidden",
                "fc" => "id",
                "value" => $form_data->id,
            ])
        ?>
    
                <?=
                    form::input([
                        "title" => "Gambar",
                        "type" => "file",
                        "fc" => "gambar",
                        "placeholder" => "tambahkan gambar",
                        "value" => $form_data->gambar,
                        "horizontal" => true
                    ])
                ?>
            
                <?=
                    form::input([
                        "title" => "Nama",
                        "type" => "text",
                        "fc" => "nama",
                        "placeholder" => "tambahkan nama",
                        "value" => $form_data->nama,
                        "horizontal" => true
                    ])
                ?>
            
                <?=
                    form::input([
                        "title" => "Kode",
                        "type" => "text",
                        "fc" => "kode",
                        "placeholder" => "tambahkan kode",
                        "value" => $form_data->kode,
                        "horizontal" => true
                    ])
                ?>
            
                <?=
                    form::select_db([
                        "title" => "Kategori",
                        "type" => "password",
                        "fc" => "kategori",
                        "placeholder" => "tambahkan kategori",
                        "db" => "kategoriproduk",
                        "data" => "id",
                        "name" => "pilihan",
                        "selected" => $form_data->kategori,
                        "horizontal" => true
                    ])
                ?>
            
                <?=
                    form::select_db([
                        "title" => "Unit",
                        "type" => "password",
                        "fc" => "unit",
                        "placeholder" => "tambahkan unit",
                        "db" => "satuan",
                        "data" => "id",
                        "name" => "satuan",
                        "selected" => $form_data->unit,
                        "horizontal" => true
                    ])
                ?>
            
                <?=
                    form::editor([
                        "title" => "Deskripsi",
                        "type" => "text",
                        "fc" => "deskripsi",
                        "placeholder" => "tambahkan deskripsi",
                        "value" => $form_data->deskripsi,
                        "horizontal" => true
                    ])
                ?>
            
                <?=
                    form::input([
                        "title" => "Barcode",
                        "type" => "text",
                        "fc" => "barcode",
                        "placeholder" => "tambahkan barcode",
                        "value" => $form_data->barcode,
                        "horizontal" => true
                    ])
                ?>
            
                <?=
                    form::select_db([
                        "title" => "Jenis_barang",
                        "type" => "password",
                        "fc" => "jenis_barang",
                        "placeholder" => "tambahkan jenis_barang",
                        "db" => "jenisbarang",
                        "data" => "id",
                        "name" => "pilihan",
                        "selected" => $form_data->jenis_barang,
                        "horizontal" => true
                    ])
                ?>
            

                        <div class="cards mt-5">
              <div class="card-header d-flex p-0">
                <ul class="nav nav-pills ">
                  <li class="nav-item"><a class="nav-link active" href="#tab_1" data-toggle="tab">Harga & Pengaturan</a></li>
                  <li class="nav-item"><a class="nav-link" href="#tab_2" data-toggle="tab">Product Bundle</a></li>
                </ul>
              </div><!-- /.card-header -->
              <div class="card-body">
                <div class="tab-content">
                  <div class="tab-pane active" id="tab_1">
                    
                    
                        <!-- setting pembelian -->
                <div class="card card-primary">
                    <div class="card-header">
                        Saya beli produk ini
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-4">
                                <?=
                                    form::input([
                                        "title" => "Harga Beli",
                                        "type" => "number",
                                        "fc" => "harga_beli",
                                        "placeholder" => "tambahkan harga_beli",
                                        "value" => $form_data->harga_beli,
                                    ])
                                ?>
                            </div>
                            <div class="col-sm-4">
                                <?=
                                    form::select_db([
                                        "title" => "Akun Pembelian",
                                        "type" => "password",
                                        "fc" => "akun_pembelian",
                                        "placeholder" => "tambahkan akun_pembelian",
                                        "db" => "akun",
                                        "data" => "id",
                                        "name" => "nama_akun",
                                        "selected" => $form_data->akun_pembelian,
                                    ])
                                ?>
                            </div>
                            <div class="col-sm-4">
                                    <?=
                                        form::select_db([
                                            "title" => "Pajak Beli",
                                            "type" => "text",
                                            "fc" => "pajak_pembelian",
                                            "placeholder" => "tambahkan pajak_pembelian",
                                            "db" => "pajak",
                                            "data" => "id",
                                            "name" => "nama",
                                            "selected" => $form_data->pajak_pembelian,
                                        ])
                                    ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card card-primary">
                    <div class="card-header">
                        Saya jual produk ini
                    </div>
                    <div class="card-body">
                <!-- setting pembelian -->
                        <div class="row">
                            <div class="col-sm-4">
                                <?=
                                    form::input([
                                        "title" => "Harga Jual",
                                        "type" => "number",
                                        "fc" => "harga_jual",
                                        "placeholder" => "tambahkan harga_jual",
                                        "value" => $form_data->harga_jual,
                                    ])
                                ?>
                            </div>
                            <div class="col-sm-4">
                                <?=
                                    form::select_db([
                                        "title" => "Akun Penjualan",
                                        "type" => "password",
                                        "fc" => "akun_penjualan",
                                        "placeholder" => "tambahkan akun_penjualan",
                                        "db" => "akun",
                                        "data" => "id",
                                        "name" => "nama_akun",
                                        "selected" => $form_data->akun_penjualan,
                                    ])
                                ?>
                            </div>
                            <div class="col-sm-4">
                                    <?=
                                        form::select_db([
                                            "title" => "Pajak Jual",
                                            "type" => "text",
                                            "fc" => "pajak_jual",
                                            "placeholder" => "tambahkan pajak_jual",
                                            "db" => "pajak",
                                            "data" => "id",
                                            "name" => "nama",
                                            "selected" => $form_data->pajak_jual,
                                        ])
                                    ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card card-primary">
                    <div class="card-header">
                        Monitor Persediaan
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-6">
                                <?=
                                    form::input([
                                        "title" => "Batas Stok",
                                        "type" => "number",
                                        "fc" => "batas_stok",
                                        "placeholder" => "tambahkan batas_stok",
                                        "value" => $form_data->batas_stok,
                                    ])
                                ?>
                            </div>
                            <div class="col-sm-6">
                                <?=
                                    form::select_db([
                                        "title" => "Akun Stok",
                                        "type" => "password",
                                        "fc" => "akun_stok",
                                        "placeholder" => "tambahkan akun_stok",
                                        "db" => "akun",
                                        "data" => "id",
                                        "name" => "nama_akun",
                                        "selected" => $form_data->akun_stok,
                                    ])
                                ?>
                            </div>
                        </div>
                    </div>
                </div>


                  </div>
                  <!-- /.tab-pane -->
                  <div class="tab-pane" id="tab_2">
                    The European languages are members of the same family. Their separate existence is a myth.
                    For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ
                    in their grammar, their pronunciation and their most common words. Everyone realizes why a
                    new common language would be desirable: one could refuse to pay expensive translators. To
                    achieve this, it would be necessary to have uniform grammar, pronunciation and more common
                    words. If several languages coalesce, the grammar of the resulting language is more simple
                    and regular than that of the individual languages.
                  </div>
                  <!-- /.tab-pane -->
                </div>
                <!-- /.tab-content -->
              </div><!-- /.card-body -->
            </div>


                        <div class="form-group">
                          <button type="submit" class="btn btn-primary">Simpan</button>
                          <a class="btn btn-default" href="<?= site_url('admin/produk'); ?>">Back</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
      </div>
    </section>
</div>

