<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
        <div class="col-sm-6">
            <h1 class="m-0 text-dark">Tambahkan Produk</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="{{ url('toko') }}">Home</a></li>
            </ol>
        </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <section class="content" style="padding: 20px;">
      <div class="row">
        <div class="col-12">
            <div class="card" style="padding: 20px;">
                <div class="card-body">
                    <form action="<?= site_url('admin/produk/simpan') ?>" method="post" enctype="multipart/form-data">
                        
                <?=
                    form::input([
                        "title" => "Gambar",
                        "type" => "file",
                        "fc" => "gambar",
                        "placeholder" => "tambahkan gambar",
                        "horizontal" => true
                    ])
                ?>
            
                <?=
                    form::input([
                        "title" => "Nama",
                        "type" => "text",
                        "fc" => "nama",
                        "placeholder" => "tambahkan nama",
                        "horizontal" => true
                    ])
                ?>
            
                <?=
                    form::input([
                        "title" => "Kode",
                        "type" => "text",
                        "fc" => "kode",
                        "placeholder" => "tambahkan kode",
                        "horizontal" => true
                    ])
                ?>
            
                <?=
                    form::select_db([
                        "title" => "Kategori",
                        "type" => "password",
                        "fc" => "kategori",
                        "placeholder" => "tambahkan kategori",
                        "db" => "kategoriproduk",
                        "data" => "id",
                        "name" => "pilihan",
                        "horizontal" => true
                    ])
                ?>
            
                <?=
                    form::select_db([
                        "title" => "Unit",
                        "type" => "password",
                        "fc" => "unit",
                        "placeholder" => "tambahkan unit",
                        "db" => "satuan",
                        "data" => "id",
                        "name" => "satuan",
                        "horizontal" => true
                    ])
                ?>
            
                <?=
                    form::editor([
                        "title" => "Deskripsi",
                        "type" => "text",
                        "fc" => "deskripsi",
                        "placeholder" => "tambahkan deskripsi",
                        "horizontal" => true
                    ])
                ?>

                <?=
                    form::input([
                        "title" => "Barcode",
                        "type" => "text",
                        "fc" => "barcode",
                        "placeholder" => "tambahkan barcode",
                        "horizontal" => true
                    ])
                ?>
            
                <?=
                    form::select_db([
                        "title" => "Jenis Barang",
                        "type" => "password",
                        "fc" => "jenis_barang",
                        "placeholder" => "tambahkan jenis_barang",
                        "db" => "jenisbarang",
                        "data" => "id",
                        "name" => "pilihan",
                        "horizontal" => true
                    ])
                ?>

                <script>

                    $('#jenis_barang').val(1);
                    $('#jenis_barang').select2().trigger('change');
                        
                </script>


                <script>
                    $('#jenis_barang').on('select2:select', function (e) {
                        var data = e.params.data;
                        var val = data.element.value;
                        if (val == 2) {
                            document.getElementById('tab2').setAttribute('data-toggle', 'tab');

                            document.getElementById('harga_beli').setAttribute('disabled', true);
                            document.getElementById('akun_pembelian').setAttribute('disabled', true);
                            document.getElementById('pajak_pembelian').setAttribute('disabled', true);

                        }else{
                            document.getElementById('tab2').setAttribute('data-toggle', 'tabs');
                            document.getElementById('tab1').setAttribute('class', 'nav-link active');
                            document.getElementById('tab2').setAttribute('class', 'nav-link');
                            document.getElementById('tab_1').setAttribute('class', 'tab-pane active');
                            document.getElementById('tab_2').setAttribute('class', 'tab-pane');

                            document.getElementById('harga_beli').removeAttribute('disabled');
                            document.getElementById('akun_pembelian').removeAttribute('disabled');
                            document.getElementById('pajak_pembelian').removeAttribute('disabled');

                        }
                    });
                
                </script>

            <div class="cards mt-5">
              <div class="card-header d-flex p-0">
                <ul class="nav nav-pills ">
                  <li class="nav-item"><a id="tab1" class="nav-link active" href="#tab_1" data-toggle="tab">Harga & Pengaturan</a></li>
                  <li class="nav-item"><a id="tab2" class="nav-link " href="#tab_2" data-toggle="tabs">Product Bundle</a></li>
                </ul>
              </div><!-- /.card-header -->
              <div class="card-body">
                <div class="tab-content">
                  <div class="tab-pane active" id="tab_1">
                    
                    
                        <!-- setting pembelian -->
                <div class="card card-primary">
                    <div class="card-header">
                        Saya beli produk ini
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-4">
                                <?=
                                    form::input([
                                        "title" => "Harga Beli",
                                        "type" => "number",
                                        "fc" => "harga_beli",
                                        "placeholder" => "tambahkan harga_beli",
                                    ])
                                ?>
                            </div>
                            <div class="col-sm-4">
                                <?=
                                    form::select_db([
                                        "title" => "Akun Pembelian",
                                        "type" => "password",
                                        "fc" => "akun_pembelian",
                                        "placeholder" => "tambahkan akun_pembelian",
                                        "db" => "akun",
                                        "data" => "id",
                                        "name" => "nama_akun",
                                    ])
                                ?>
                            </div>
                            <div class="col-sm-4">
                                    <?=
                                        form::select_db([
                                            "title" => "Pajak Beli",
                                            "type" => "text",
                                            "fc" => "pajak_pembelian",
                                            "placeholder" => "tambahkan pajak_pembelian",
                                            "db" => "pajak",
                                            "data" => "id",
                                            "name" => "nama",
                                        ])
                                    ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card card-primary">
                    <div class="card-header">
                        Saya jual produk ini
                    </div>
                    <div class="card-body">
                <!-- setting pembelian -->
                        <div class="row">
                            <div class="col-sm-4">
                                <?=
                                    form::input([
                                        "title" => "Harga Jual",
                                        "type" => "number",
                                        "fc" => "harga_jual",
                                        "placeholder" => "tambahkan harga_jual",
                                    ])
                                ?>
                            </div>
                            <div class="col-sm-4">
                                <?=
                                    form::select_db([
                                        "title" => "Akun Penjualan",
                                        "type" => "password",
                                        "fc" => "akun_penjualan",
                                        "placeholder" => "tambahkan akun_penjualan",
                                        "db" => "akun",
                                        "data" => "id",
                                        "name" => "nama_akun",
                                    ])
                                ?>
                            </div>
                            <div class="col-sm-4">
                                    <?=
                                        form::select_db([
                                            "title" => "Pajak Jual",
                                            "type" => "text",
                                            "fc" => "pajak_jual",
                                            "placeholder" => "tambahkan pajak_jual",
                                            "db" => "pajak",
                                            "data" => "id",
                                            "name" => "nama",
                                        ])
                                    ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card card-primary">
                    <div class="card-header">
                        Monitor Persediaan
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-6">
                                <?=
                                    form::input([
                                        "title" => "Batas Stok",
                                        "type" => "number",
                                        "fc" => "batas_stok",
                                        "placeholder" => "tambahkan batas_stok",
                                    ])
                                ?>
                            </div>
                            <div class="col-sm-6">
                                <?=
                                    form::select_db([
                                        "title" => "Akun Stok",
                                        "type" => "password",
                                        "fc" => "akun_stok",
                                        "placeholder" => "tambahkan akun_stok",
                                        "db" => "akun",
                                        "data" => "id",
                                        "name" => "nama_akun",
                                    ])
                                ?>
                            </div>
                        </div>
                    </div>
                </div>


                  </div>
                  <!-- /.tab-pane -->
                  <div class="tab-pane" id="tab_2">
                    <div class="scroll-table mt-5 mb-3">
                        <table class="table" id="produk-list">
                            <tr class="bg-primary">
                                <th class="text-center">No</th>
                                <th class="text-center">Nama produk</th>
                                <th class="text-center">Qty</th>
                                <th class="text-center">Harga</th>
                            </tr>
                        </table>
                        <div class="text-center mb-5">
                            <button type="button" id="tambah-barang" class="btn btn-primary"><i class="fas fa-plus"></i> Tambah Barang</button>
                        </div>
                    </div>
                  </div>
                  <!-- /.tab-pane -->
                </div>
                <!-- /.tab-content -->
              </div><!-- /.card-body -->
            </div>




                
            
                        <div class="form-group">
                          <button type="submit" class="btn btn-primary">Simpan</button>
                          <a class="btn btn-default" href="<?= site_url('admin/produk'); ?>">Back</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
      </div>
    </section>
</div>

<script>
$(document).on('click', '#tambah-barang', function(){

        var sl = Array.from(document.querySelectorAll('tr[data-no]'));

        var pl = sl.length + 1;

        console.log(sl);

        $.ajax({
            url: '<?= site_url('admin/produk/temp/')?>'+pl,
            success:function(res){
                $("#produk-list").append(res)
            }
        })

    })

</script>