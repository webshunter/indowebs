<tr data-no="<?= $urutan ?>">
    <td><?= $urutan ?></td>
    <td>
        <?=
            form::select_db([
                "type" => "password",
                "fc" => "databarangpembelian[$urutan][produk]",
                "placeholder" => "tambahkan kode",
                "db" => "produk",
                "data" => "id",
                "name" => "nama",
                "condition" => [
                    ['delete_set', '=', '0'],
                ]
            ])
        ?>
    </td>
    <td>
        <?=
            form::input([
                "type" => "number",
                "fc" => "databarangpembelian[$urutan][qty]",
                "placeholder" => "qty",
            ])
        ?>
    </td>
    <td>
        <?=
            form::input([
                "type" => "number",
                "fc" => "databarangpembelian[$urutan][harga]",
                "placeholder" => "harga",
            ])
        ?>
    </td>
</tr>