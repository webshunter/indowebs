
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
        <div class="col-sm-6">
            <h1 class="m-0 text-dark">Produk</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
        <?php
            link_button([
                "link" => "admin/produk/tambah_data",
                "class" => "btn btn-primary float-right",
                "text" => "Tambah Data",
            ]);
        ?>
        </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <section class="content">


                        <div class="row">

                            <div class="col-md-3">
                              <div class="card card-primary card-outline">
                                <div class="card-body">
                                  <div class="row d-flex align-items-center">
                                    <div class="col-4">
                                      <i style="font-size: 25px;" class="fas fa-tag"></i>
                                    </div>
                                    <div class="col-8">
                                      <h3 style="margin: 0;"><span><?= $stokbarang ?></span> Jenis</h3>
                                      <p style="margin: 0;">Stok Tersedia</p>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>

                            <div class="col-md-3">
                              <div class="card card-primary card-outline">
                                <div class="card-body">
                                  <div class="row d-flex align-items-center">
                                    <div class="col-4">
                                      <i style="font-size: 25px;" class="fas fa-tag"></i>
                                    </div>
                                    <div class="col-8">
                                      <h3 style="margin: 0;"><span>0</span> Jenis</h3>
                                      <p style="margin: 0;">Segera Habis</p>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>

                            <div class="col-md-3">
                              <div class="card card-primary card-outline">
                                <div class="card-body">
                                  <div class="row d-flex align-items-center">
                                    <div class="col-4">
                                      <i style="font-size: 25px;" class="fas fa-tag"></i>
                                    </div>
                                    <div class="col-8">
                                      <h3 style="margin: 0;"><span><?= $stokbaranghabis ?></span> Jenis</h3>
                                      <p style="margin: 0;">Stok Habis</p>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>

                            <div class="col-md-3">
                              <div class="card card-primary card-outline">
                                <div class="card-body">
                                  <div class="row d-flex align-items-center">
                                    <div class="col-4">
                                      <i style="font-size: 25px;" class="fas fa-tag"></i>
                                    </div>
                                    <div class="col-8">
                                      <h3 style="margin: 0;"><span><?= $daftargudang ?></span></h3>
                                      <p style="margin: 0;">Daftar Gudang</p>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>

                          </div>



      <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <?php
                        link_button([
                            "link" => "admin/produk/exls",
                            "class" => "btn btn-primary",
                            "text" => "Export Excel",
                        ]);
                    ?>
                </div>
                <div class="card-body">
                    <?= $datatable ?>
                </div>
            </div>
        </div>
      </div>
    </section>
</div>
<script>
$(document).ready(function(){
    tableku.on( 'draw', function () {

        function formatRupiah(angka, prefix){
			var number_string = angka.replace(/[^,\d]/g, '').toString(),
			split   		= number_string.split(','),
			sisa     		= split[0].length % 3,
			rupiah     		= split[0].substr(0, sisa),
			ribuan     		= split[0].substr(sisa).match(/\d{3}/gi);

			// tambahkan titik jika yang di input sudah menjadi angka ribuan
			if(ribuan){
				separator = sisa ? '.' : '';
				rupiah += separator + ribuan.join('.');
			}

			rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
			return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
		}

        Array.from(document.querySelectorAll('.bts')).forEach(function(elm){
            if(elm.innerText == ''){
                elm.innerText = '-';
            }else{
                elm.innerText = formatRupiah(elm.innerText);
            }
        })

        Array.from(document.querySelectorAll('.hb')).forEach(function(elm){
            if(elm.innerText == ''){
                elm.innerText = '-';
            }else{
                elm.innerText = 'Rp. '+formatRupiah(elm.innerText)+',00';
            }
        })

        Array.from(document.querySelectorAll('.hj')).forEach(function(elm){
            if(elm.innerText == ''){
                elm.innerText = '-';
            }else{
                elm.innerText = 'Rp. '+formatRupiah(elm.innerText)+',00';
            }
        })

        Array.from(document.querySelectorAll('.qty')).forEach(function(elm){
            if(elm.innerText == ''){
                elm.innerText = '-';
            }
        })

        Array.from(document.querySelectorAll('.hrr')).forEach(function(elm){
            if(elm.innerText == ''){
                elm.innerText = 'Rp. 0,00';
            }
        })

        Array.from(document.querySelectorAll('.hbt')).forEach(function(elm){
            if(elm.innerText == ''){
                elm.innerText = 'Rp. 0,00';
            }
        })

    });
})

</script>
