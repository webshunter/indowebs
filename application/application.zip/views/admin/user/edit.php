<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
        <div class="col-sm-6">
            <h1 class="m-0 text-dark">Ubah User</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="{{ url('toko') }}">Home</a></li>
            </ol>
        </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <section class="content">
      <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form action="<?= site_url('admin/user/update') ?>" method="post" enctype="multipart/form-data">

        <?=
            form::input([
                "type" => "hidden",
                "fc" => "id",
                "value" => $form_data->id,
            ])
        ?>

                <?=
                    form::input([
                        "title" => "Foto",
                        "type" => "file",
                        "fc" => "foto",
                        "placeholder" => "tambahkan foto",
                        "value" => $form_data->foto,
                    ])
                ?>

                <?=
                    form::input([
                        "title" => "Nama",
                        "type" => "text",
                        "fc" => "nama",
                        "placeholder" => "tambahkan nama",
                        "value" => $form_data->nama,
                    ])
                ?>

                <?=
                    form::select_db([
                        "title" => "Level",
                        "type" => "password",
                        "fc" => "level",
                        "placeholder" => "tambahkan level",
                        "db" => "leveluser",
                        "data" => "id",
                        "name" => "pilihan",
                        "selected" => $form_data->level,
                    ])
                ?>

                <?=
                    form::input([
                        "title" => "Username",
                        "type" => "username",
                        "fc" => "username",
                        "placeholder" => "tambahkan username",
                        "value" => $form_data->username,
                    ])
                ?>

                <?=
                    form::input([
                        "title" => "Password",
                        "type" => "password",
                        "fc" => "password",
                        "placeholder" => "tambahkan password",
                        "value" => $form_data->passwordview,
                    ])
                ?>

                <?=
                    form::input([
                        "title" => "Konfirmasi Password",
                        "type" => "password",
                        "fc" => "passwordview",
                        "placeholder" => "isikan ulang password",
                        "value" => $form_data->passwordview,
                    ])
                ?>

                        <div class="form-group">
                          <button type="button" id="save" class="btn btn-primary">Simpan</button>
                          <a class="btn btn-default" href="<?= site_url('admin/user'); ?>">Back</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
      </div>
    </section>
</div>

<script type="text/javascript">
  setInterval(function(){

    var a = document.getElementById('password').value;
    var b = document.getElementById('passwordview').value;

    if(a != "" && b != ""){

      if (a == b) {

        var s = document.getElementById('save');

        s.setAttribute('type', 'submit');

        s.className = "btn btn-primary";

      }else{

        var s = document.getElementById('save');

        s.setAttribute('type', 'button');

        s.className = "btn btn-default";

      }

    }else{

      var s = document.getElementById('save');

      s.setAttribute('type', 'button');

      s.className = "btn btn-default";

    }

  },100)
</script>
