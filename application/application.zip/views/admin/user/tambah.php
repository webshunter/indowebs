<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
        <div class="col-sm-6">
            <h1 class="m-0 text-dark">Tambahkan User</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="{{ url('toko') }}">Home</a></li>
            </ol>
        </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <section class="content">
      <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                <?php

                  pesan('', 'show', 'Warning!');

                ?>

                <form action="<?= site_url('admin/user/simpan') ?>" method="post" enctype="multipart/form-data">

                <?=
                    form::input([
                        "title" => "Foto",
                        "type" => "file",
                        "fc" => "foto",
                        "placeholder" => "tambahkan foto",
                    ])
                ?>

                <?=
                    form::input([
                        "title" => "Nama",
                        "type" => "text",
                        "fc" => "nama",
                        "placeholder" => "tambahkan nama",
                    ])
                ?>

                <?=
                    form::select_db([
                        "title" => "Level",
                        "type" => "password",
                        "fc" => "level",
                        "placeholder" => "tambahkan level",
                        "db" => "leveluser",
                        "data" => "id",
                        "name" => "pilihan",
                    ])
                ?>

                <?=
                    form::input([
                        "title" => "Username",
                        "type" => "username",
                        "fc" => "username",
                        "placeholder" => "tambahkan username",
                    ])
                ?>

                <?=
                    form::input([
                        "title" => "Password",
                        "type" => "password",
                        "fc" => "password",
                        "placeholder" => "tambahkan password",
                    ])
                ?>

                <?=
                    form::input([
                        "title" => "Konfirmasi Password",
                        "type" => "password",
                        "fc" => "passwordview",
                        "placeholder" => "isikan ulang password",
                    ])
                ?>

                        <div class="form-group">
                          <button type="button" id="save" class="btn btn-default">Simpan</button>
                          <a class="btn btn-default" href="<?= site_url('admin/user'); ?>">Back</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
      </div>
    </section>
</div>

<script type="text/javascript">
  setInterval(function(){

    var a = document.getElementById('password').value;
    var b = document.getElementById('passwordview').value;

    if(a != "" && b != ""){

      if (a == b) {

        var s = document.getElementById('save');

        s.setAttribute('type', 'submit');

        s.className = "btn btn-primary";

      }else{

        var s = document.getElementById('save');

        s.setAttribute('type', 'button');

        s.className = "btn btn-default";

      }

    }else{
      
      var s = document.getElementById('save');

      s.setAttribute('type', 'button');

      s.className = "btn btn-default";

    }

  },100)
</script>
